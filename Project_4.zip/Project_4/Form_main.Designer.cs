﻿namespace Project_4
{
    partial class Form_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle65 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle67 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1_6 = new System.Windows.Forms.Panel();
            this.panel1_5 = new System.Windows.Forms.Panel();
            this.panel1_4 = new System.Windows.Forms.Panel();
            this.panel1_3 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1_1 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button8 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3_2_2 = new System.Windows.Forms.Button();
            this.panel105 = new System.Windows.Forms.Panel();
            this.label3_3_2 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label3_2_2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label3_1_5 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label3_1_3 = new System.Windows.Forms.Label();
            this.panel104 = new System.Windows.Forms.Panel();
            this.label3_1_4 = new System.Windows.Forms.Label();
            this.button3_1_3 = new System.Windows.Forms.Button();
            this.textBox3_1_2 = new System.Windows.Forms.TextBox();
            this.label3_1_2 = new System.Windows.Forms.Label();
            this.button3_2_1 = new System.Windows.Forms.Button();
            this.textBox3_1_1 = new System.Windows.Forms.TextBox();
            this.button3_3_1 = new System.Windows.Forms.Button();
            this.textBox3_3_1 = new System.Windows.Forms.TextBox();
            this.label3_1_1 = new System.Windows.Forms.Label();
            this.panel103 = new System.Windows.Forms.Panel();
            this.button3_3_2 = new System.Windows.Forms.Button();
            this.textBox3_2_1 = new System.Windows.Forms.TextBox();
            this.button3_3_3 = new System.Windows.Forms.Button();
            this.label3_2_1 = new System.Windows.Forms.Label();
            this.dataGridView3_2_1 = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridView3_3_1 = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label3_3_1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel102 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.panel101 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button7 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.Daycontainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button4_6 = new System.Windows.Forms.Button();
            this.button4_1 = new System.Windows.Forms.Button();
            this.dataGridView4_1 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4_1_1 = new System.Windows.Forms.Label();
            this.panel119 = new System.Windows.Forms.Panel();
            this.label63 = new System.Windows.Forms.Label();
            this.panel118 = new System.Windows.Forms.Panel();
            this.panel117 = new System.Windows.Forms.Panel();
            this.label4_1_6 = new System.Windows.Forms.Label();
            this.label4_1_5 = new System.Windows.Forms.Label();
            this.panel115 = new System.Windows.Forms.Panel();
            this.label4_1_4 = new System.Windows.Forms.Label();
            this.panel113 = new System.Windows.Forms.Panel();
            this.label4_1_3 = new System.Windows.Forms.Label();
            this.panel112 = new System.Windows.Forms.Panel();
            this.label4_1_2 = new System.Windows.Forms.Label();
            this.panel111 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView4_2 = new System.Windows.Forms.DataGridView();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel4_2 = new System.Windows.Forms.Panel();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel132 = new System.Windows.Forms.Panel();
            this.label70 = new System.Windows.Forms.Label();
            this.panel131 = new System.Windows.Forms.Panel();
            this.label69 = new System.Windows.Forms.Label();
            this.panel130 = new System.Windows.Forms.Panel();
            this.label68 = new System.Windows.Forms.Label();
            this.panel129 = new System.Windows.Forms.Panel();
            this.label64 = new System.Windows.Forms.Label();
            this.panel128 = new System.Windows.Forms.Panel();
            this.label62 = new System.Windows.Forms.Label();
            this.panel127 = new System.Windows.Forms.Panel();
            this.label61 = new System.Windows.Forms.Label();
            this.panel126 = new System.Windows.Forms.Panel();
            this.label59 = new System.Windows.Forms.Label();
            this.panel125 = new System.Windows.Forms.Panel();
            this.label57 = new System.Windows.Forms.Label();
            this.panel124 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel120 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.button4_2 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label21 = new System.Windows.Forms.Label();
            this.dataGridView4_5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button4_4 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label23 = new System.Windows.Forms.Label();
            this.dataGridView4_7 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button4_5 = new System.Windows.Forms.Button();
            this.button4_3 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.dataGridView4_6 = new System.Windows.Forms.DataGridView();
            this.Column33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button4_1_1 = new System.Windows.Forms.Button();
            this.textBox4_1_6 = new System.Windows.Forms.TextBox();
            this.label4_6 = new System.Windows.Forms.Label();
            this.label4_1 = new System.Windows.Forms.Label();
            this.textBox4_1_5 = new System.Windows.Forms.TextBox();
            this.label4_2 = new System.Windows.Forms.Label();
            this.label4_5 = new System.Windows.Forms.Label();
            this.label4_3 = new System.Windows.Forms.Label();
            this.panel4_1_1 = new System.Windows.Forms.Panel();
            this.label4_4 = new System.Windows.Forms.Label();
            this.textBox4_1_4 = new System.Windows.Forms.TextBox();
            this.textBox4_1_1 = new System.Windows.Forms.TextBox();
            this.textBox4_1_3 = new System.Windows.Forms.TextBox();
            this.textBox4_1_2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel106 = new System.Windows.Forms.Panel();
            this.panel107 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.button5 = new System.Windows.Forms.Button();
            this.main_textBox = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1_2 = new System.Windows.Forms.Panel();
            this.button1_1 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel123 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel122 = new System.Windows.Forms.Panel();
            this.label66 = new System.Windows.Forms.Label();
            this.panel121 = new System.Windows.Forms.Panel();
            this.label65 = new System.Windows.Forms.Label();
            this.panel116 = new System.Windows.Forms.Panel();
            this.label60 = new System.Windows.Forms.Label();
            this.panel114 = new System.Windows.Forms.Panel();
            this.label58 = new System.Windows.Forms.Label();
            this.panel109 = new System.Windows.Forms.Panel();
            this.panel110 = new System.Windows.Forms.Panel();
            this.panel108 = new System.Windows.Forms.Panel();
            this.button21 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Daycontainer1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel82 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.panel84 = new System.Windows.Forms.Panel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel99 = new System.Windows.Forms.Panel();
            this.panel100 = new System.Windows.Forms.Panel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.Column47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label49 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel58 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_3_1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel13.SuspendLayout();
            this.Daycontainer.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_1)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel4_2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_5)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_6)).BeginInit();
            this.panel8.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel57.SuspendLayout();
            this.Daycontainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.panel58.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.chart1);
            this.panel1.Controls.Add(this.panel1_1);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(325, 148);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1240, 697);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.panel1_6);
            this.panel6.Controls.Add(this.panel1_5);
            this.panel6.Controls.Add(this.panel1_4);
            this.panel6.Controls.Add(this.panel1_3);
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Location = new System.Drawing.Point(712, 1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(527, 302);
            this.panel6.TabIndex = 17;
            this.panel6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseClick);
            // 
            // panel1_6
            // 
            this.panel1_6.BackColor = System.Drawing.Color.Black;
            this.panel1_6.Location = new System.Drawing.Point(237, 206);
            this.panel1_6.Name = "panel1_6";
            this.panel1_6.Size = new System.Drawing.Size(210, 1);
            this.panel1_6.TabIndex = 28;
            // 
            // panel1_5
            // 
            this.panel1_5.BackColor = System.Drawing.Color.Black;
            this.panel1_5.Location = new System.Drawing.Point(237, 159);
            this.panel1_5.Name = "panel1_5";
            this.panel1_5.Size = new System.Drawing.Size(210, 1);
            this.panel1_5.TabIndex = 28;
            // 
            // panel1_4
            // 
            this.panel1_4.BackColor = System.Drawing.Color.Black;
            this.panel1_4.Location = new System.Drawing.Point(237, 112);
            this.panel1_4.Name = "panel1_4";
            this.panel1_4.Size = new System.Drawing.Size(210, 1);
            this.panel1_4.TabIndex = 28;
            // 
            // panel1_3
            // 
            this.panel1_3.BackColor = System.Drawing.Color.Black;
            this.panel1_3.Location = new System.Drawing.Point(237, 65);
            this.panel1_3.Name = "panel1_3";
            this.panel1_3.Size = new System.Drawing.Size(210, 1);
            this.panel1_3.TabIndex = 27;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(389, 249);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(127, 35);
            this.button6.TabIndex = 7;
            this.button6.TabStop = false;
            this.button6.Text = "신규등록";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.MouseLeave += new System.EventHandler(this.button6_MouseLeave);
            this.button6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button6_MouseMove);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(241, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(206, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "010122";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(76, 249);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(266, 24);
            this.label10.TabIndex = 8;
            this.label10.Text = "입력한 내용을 확인해주세요.";
            this.label10.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(76, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 24);
            this.label6.TabIndex = 1;
            this.label6.Text = "생년월일";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label12.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(241, 182);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(206, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "대전시 서구";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(241, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "이윤서";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label11.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(241, 135);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(203, 25);
            this.label11.TabIndex = 11;
            this.label11.Text = "01012345678";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(76, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "이름";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(76, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "주소";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(76, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "전화번호";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(995, 331);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(0, 20);
            this.label35.TabIndex = 171;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox7.Location = new System.Drawing.Point(1500, 547);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(200, 29);
            this.textBox7.TabIndex = 6;
            this.textBox7.Click += new System.EventHandler(this.textBox7_Click);
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            this.textBox7.Enter += new System.EventHandler(this.textBox7_Enter);
            this.textBox7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox7_KeyDown);
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.Location = new System.Drawing.Point(1500, 655);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(200, 29);
            this.textBox6.TabIndex = 5;
            this.textBox6.Click += new System.EventHandler(this.textBox6_Click);
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            this.textBox6.Enter += new System.EventHandler(this.textBox6_Enter);
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyDown);
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button13.Location = new System.Drawing.Point(569, 632);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(126, 38);
            this.button13.TabIndex = 16;
            this.button13.Text = "수납";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            this.button13.MouseLeave += new System.EventHandler(this.button13_MouseLeave);
            this.button13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button13_MouseMove);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(1500, 653);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(200, 29);
            this.textBox5.TabIndex = 4;
            this.textBox5.Click += new System.EventHandler(this.textBox5_Click);
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.Enter += new System.EventHandler(this.textBox5_Enter);
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            chartArea2.Name = "ChartArea2";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.ChartAreas.Add(chartArea2);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(712, 306);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(527, 389);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseClick);
            // 
            // panel1_1
            // 
            this.panel1_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel1_1.Location = new System.Drawing.Point(711, 304);
            this.panel1_1.Name = "panel1_1";
            this.panel1_1.Size = new System.Drawing.Size(529, 1);
            this.panel1_1.TabIndex = 26;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(1963, 293);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 29);
            this.textBox4.TabIndex = 3;
            this.textBox4.Click += new System.EventHandler(this.textBox4_Click);
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.Enter += new System.EventHandler(this.textBox4_Enter);
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column41,
            this.Column42,
            this.Column43,
            this.Column44,
            this.Column45});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.Location = new System.Drawing.Point(2, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(708, 693);
            this.dataGridView1.TabIndex = 170;
            this.dataGridView1.TabStop = false;
            // 
            // Column41
            // 
            this.Column41.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Column41.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column41.HeaderText = "시간";
            this.Column41.Name = "Column41";
            this.Column41.ReadOnly = true;
            this.Column41.Width = 69;
            // 
            // Column42
            // 
            this.Column42.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Column42.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column42.HeaderText = "나이";
            this.Column42.Name = "Column42";
            this.Column42.ReadOnly = true;
            this.Column42.Width = 69;
            // 
            // Column43
            // 
            this.Column43.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Column43.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column43.HeaderText = "생년월일";
            this.Column43.Name = "Column43";
            this.Column43.ReadOnly = true;
            // 
            // Column44
            // 
            this.Column44.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Column44.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column44.HeaderText = "전화번호";
            this.Column44.Name = "Column44";
            this.Column44.ReadOnly = true;
            // 
            // Column45
            // 
            this.Column45.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Column45.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column45.HeaderText = "주소";
            this.Column45.Name = "Column45";
            this.Column45.ReadOnly = true;
            this.Column45.Width = 69;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button8.Location = new System.Drawing.Point(551, 605);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 35);
            this.button8.TabIndex = 15;
            this.button8.TabStop = false;
            this.button8.Text = "접수";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click_2);
            this.button8.MouseLeave += new System.EventHandler(this.button8_MouseLeave);
            this.button8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button8_MouseMove);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button12.Location = new System.Drawing.Point(433, 605);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 35);
            this.button12.TabIndex = 16;
            this.button12.TabStop = false;
            this.button12.Text = "수정";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            this.button12.MouseLeave += new System.EventHandler(this.button12_MouseLeave);
            this.button12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button12_MouseMove);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9});
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(708, 650);
            this.dataGridView2.TabIndex = 14;
            this.dataGridView2.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentDoubleClick);
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column5.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column5.HeaderText = "이름";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 69;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column6.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column6.HeaderText = "나이";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 69;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column7.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column7.HeaderText = "생년월일";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column8.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column8.HeaderText = "핸드폰번호";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column9.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column9.HeaderText = "주소";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.button3_2_2);
            this.panel3.Controls.Add(this.panel105);
            this.panel3.Controls.Add(this.label3_3_2);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.label3_2_2);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.label3_1_5);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.label3_1_3);
            this.panel3.Controls.Add(this.panel104);
            this.panel3.Controls.Add(this.label3_1_4);
            this.panel3.Controls.Add(this.button3_1_3);
            this.panel3.Controls.Add(this.textBox3_1_2);
            this.panel3.Controls.Add(this.label3_1_2);
            this.panel3.Controls.Add(this.button3_2_1);
            this.panel3.Controls.Add(this.textBox3_1_1);
            this.panel3.Controls.Add(this.button3_3_1);
            this.panel3.Controls.Add(this.textBox3_3_1);
            this.panel3.Controls.Add(this.label3_1_1);
            this.panel3.Controls.Add(this.panel103);
            this.panel3.Controls.Add(this.button3_3_2);
            this.panel3.Controls.Add(this.textBox3_2_1);
            this.panel3.Controls.Add(this.button3_3_3);
            this.panel3.Controls.Add(this.label3_2_1);
            this.panel3.Controls.Add(this.dataGridView3_2_1);
            this.panel3.Controls.Add(this.dataGridView3_3_1);
            this.panel3.Controls.Add(this.label3_3_1);
            this.panel3.Location = new System.Drawing.Point(325, 148);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1240, 697);
            this.panel3.TabIndex = 5;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            this.panel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseClick);
            // 
            // button3_2_2
            // 
            this.button3_2_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_2_2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3_2_2.FlatAppearance.BorderSize = 0;
            this.button3_2_2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button3_2_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3_2_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3_2_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_2_2.Location = new System.Drawing.Point(469, 641);
            this.button3_2_2.Name = "button3_2_2";
            this.button3_2_2.Size = new System.Drawing.Size(65, 40);
            this.button3_2_2.TabIndex = 39;
            this.button3_2_2.Text = "삭제";
            this.button3_2_2.UseVisualStyleBackColor = true;
            this.button3_2_2.Visible = false;
            this.button3_2_2.Click += new System.EventHandler(this.button3_2_2_Click);
            this.button3_2_2.MouseLeave += new System.EventHandler(this.button3_2_2_MouseLeave);
            this.button3_2_2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button3_2_2_MouseMove);
            // 
            // panel105
            // 
            this.panel105.BackColor = System.Drawing.Color.Black;
            this.panel105.Location = new System.Drawing.Point(800, 674);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(240, 1);
            this.panel105.TabIndex = 38;
            this.panel105.Visible = false;
            // 
            // label3_3_2
            // 
            this.label3_3_2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3_3_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_3_2.Location = new System.Drawing.Point(800, 645);
            this.label3_3_2.Name = "label3_3_2";
            this.label3_3_2.Size = new System.Drawing.Size(240, 29);
            this.label3_3_2.TabIndex = 37;
            this.label3_3_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3_3_2.Visible = false;
            this.label3_3_2.Click += new System.EventHandler(this.label3_3_2_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(144, 674);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(240, 1);
            this.panel10.TabIndex = 38;
            this.panel10.Visible = false;
            // 
            // label3_2_2
            // 
            this.label3_2_2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3_2_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_2_2.Location = new System.Drawing.Point(144, 645);
            this.label3_2_2.Name = "label3_2_2";
            this.label3_2_2.Size = new System.Drawing.Size(240, 29);
            this.label3_2_2.TabIndex = 37;
            this.label3_2_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3_2_2.Visible = false;
            this.label3_2_2.Click += new System.EventHandler(this.label3_2_2_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(800, 58);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(240, 1);
            this.panel9.TabIndex = 36;
            // 
            // label3_1_5
            // 
            this.label3_1_5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3_1_5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_5.Location = new System.Drawing.Point(800, 30);
            this.label3_1_5.Name = "label3_1_5";
            this.label3_1_5.Size = new System.Drawing.Size(240, 29);
            this.label3_1_5.TabIndex = 35;
            this.label3_1_5.Click += new System.EventHandler(this.label3_1_5_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(220, 58);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(240, 1);
            this.panel7.TabIndex = 34;
            // 
            // label3_1_3
            // 
            this.label3_1_3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label3_1_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_3.Location = new System.Drawing.Point(220, 30);
            this.label3_1_3.Name = "label3_1_3";
            this.label3_1_3.Size = new System.Drawing.Size(240, 29);
            this.label3_1_3.TabIndex = 32;
            this.label3_1_3.Click += new System.EventHandler(this.label3_1_3_Click);
            // 
            // panel104
            // 
            this.panel104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel104.Location = new System.Drawing.Point(624, 85);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(1, 612);
            this.panel104.TabIndex = 29;
            // 
            // label3_1_4
            // 
            this.label3_1_4.AutoSize = true;
            this.label3_1_4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_4.Location = new System.Drawing.Point(723, 34);
            this.label3_1_4.Name = "label3_1_4";
            this.label3_1_4.Size = new System.Drawing.Size(50, 24);
            this.label3_1_4.TabIndex = 8;
            this.label3_1_4.Text = "이름";
            // 
            // button3_1_3
            // 
            this.button3_1_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_1_3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3_1_3.FlatAppearance.BorderSize = 0;
            this.button3_1_3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button3_1_3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3_1_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3_1_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_1_3.Location = new System.Drawing.Point(1111, 26);
            this.button3_1_3.Name = "button3_1_3";
            this.button3_1_3.Size = new System.Drawing.Size(65, 40);
            this.button3_1_3.TabIndex = 4;
            this.button3_1_3.Text = "등록";
            this.button3_1_3.UseVisualStyleBackColor = true;
            this.button3_1_3.Click += new System.EventHandler(this.button3_1_3_Click);
            this.button3_1_3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button3_1_3_KeyDown);
            this.button3_1_3.MouseLeave += new System.EventHandler(this.button3_1_3_MouseLeave);
            this.button3_1_3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button3_1_3_MouseMove);
            // 
            // textBox3_1_2
            // 
            this.textBox3_1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3_1_2.Location = new System.Drawing.Point(2803, 33);
            this.textBox3_1_2.Name = "textBox3_1_2";
            this.textBox3_1_2.Size = new System.Drawing.Size(239, 29);
            this.textBox3_1_2.TabIndex = 2;
            this.textBox3_1_2.Click += new System.EventHandler(this.textBox3_1_2_Click);
            this.textBox3_1_2.TextChanged += new System.EventHandler(this.textBox3_1_2_TextChanged);
            this.textBox3_1_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_1_2_KeyDown);
            // 
            // label3_1_2
            // 
            this.label3_1_2.AutoSize = true;
            this.label3_1_2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_2.Location = new System.Drawing.Point(144, 34);
            this.label3_1_2.Name = "label3_1_2";
            this.label3_1_2.Size = new System.Drawing.Size(50, 24);
            this.label3_1_2.TabIndex = 7;
            this.label3_1_2.Text = "코드";
            // 
            // button3_2_1
            // 
            this.button3_2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_2_1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3_2_1.FlatAppearance.BorderSize = 0;
            this.button3_2_1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button3_2_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3_2_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3_2_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_2_1.Location = new System.Drawing.Point(395, 641);
            this.button3_2_1.Name = "button3_2_1";
            this.button3_2_1.Size = new System.Drawing.Size(65, 40);
            this.button3_2_1.TabIndex = 1;
            this.button3_2_1.Text = "사용";
            this.button3_2_1.UseVisualStyleBackColor = true;
            this.button3_2_1.Visible = false;
            this.button3_2_1.Click += new System.EventHandler(this.button3_2_1_Click);
            this.button3_2_1.MouseLeave += new System.EventHandler(this.button3_2_1_MouseLeave);
            this.button3_2_1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button3_2_1_MouseMove);
            // 
            // textBox3_1_1
            // 
            this.textBox3_1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3_1_1.Location = new System.Drawing.Point(2247, 26);
            this.textBox3_1_1.Name = "textBox3_1_1";
            this.textBox3_1_1.Size = new System.Drawing.Size(278, 29);
            this.textBox3_1_1.TabIndex = 0;
            this.textBox3_1_1.Click += new System.EventHandler(this.textBox3_1_1_Click);
            this.textBox3_1_1.TextChanged += new System.EventHandler(this.textBox3_1_1_TextChanged);
            this.textBox3_1_1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_1_1_KeyDown);
            // 
            // button3_3_1
            // 
            this.button3_3_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_3_1.Location = new System.Drawing.Point(765, 645);
            this.button3_3_1.Name = "button3_3_1";
            this.button3_3_1.Size = new System.Drawing.Size(30, 30);
            this.button3_3_1.TabIndex = 1;
            this.button3_3_1.UseVisualStyleBackColor = true;
            this.button3_3_1.Visible = false;
            this.button3_3_1.Click += new System.EventHandler(this.button3_3_1_Click);
            // 
            // textBox3_3_1
            // 
            this.textBox3_3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3_3_1.Location = new System.Drawing.Point(2851, 643);
            this.textBox3_3_1.Name = "textBox3_3_1";
            this.textBox3_3_1.Size = new System.Drawing.Size(227, 29);
            this.textBox3_3_1.TabIndex = 0;
            this.textBox3_3_1.Visible = false;
            this.textBox3_3_1.Click += new System.EventHandler(this.textBox3_3_1_Click);
            this.textBox3_3_1.TextChanged += new System.EventHandler(this.textBox3_3_1_TextChanged);
            // 
            // label3_1_1
            // 
            this.label3_1_1.AutoSize = true;
            this.label3_1_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_1_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(202)))), ((int)(((byte)(224)))));
            this.label3_1_1.Location = new System.Drawing.Point(17, 17);
            this.label3_1_1.Name = "label3_1_1";
            this.label3_1_1.Size = new System.Drawing.Size(65, 54);
            this.label3_1_1.TabIndex = 3;
            this.label3_1_1.Text = "제 품\r\n검 색";
            // 
            // panel103
            // 
            this.panel103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel103.Location = new System.Drawing.Point(3, 85);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(1240, 1);
            this.panel103.TabIndex = 28;
            // 
            // button3_3_2
            // 
            this.button3_3_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3_3_2.Location = new System.Drawing.Point(1044, 645);
            this.button3_3_2.Name = "button3_3_2";
            this.button3_3_2.Size = new System.Drawing.Size(30, 30);
            this.button3_3_2.TabIndex = 2;
            this.button3_3_2.UseVisualStyleBackColor = true;
            this.button3_3_2.Visible = false;
            this.button3_3_2.Click += new System.EventHandler(this.button3_3_2_Click);
            // 
            // textBox3_2_1
            // 
            this.textBox3_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3_2_1.Location = new System.Drawing.Point(2169, 643);
            this.textBox3_2_1.Name = "textBox3_2_1";
            this.textBox3_2_1.Size = new System.Drawing.Size(278, 29);
            this.textBox3_2_1.TabIndex = 0;
            this.textBox3_2_1.Visible = false;
            this.textBox3_2_1.Click += new System.EventHandler(this.textBox3_2_1_Click);
            this.textBox3_2_1.TextChanged += new System.EventHandler(this.textBox3_2_1_TextChanged);
            // 
            // button3_3_3
            // 
            this.button3_3_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3_3_3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3_3_3.FlatAppearance.BorderSize = 0;
            this.button3_3_3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button3_3_3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3_3_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3_3_3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_3_3.Location = new System.Drawing.Point(1078, 643);
            this.button3_3_3.Name = "button3_3_3";
            this.button3_3_3.Size = new System.Drawing.Size(65, 40);
            this.button3_3_3.TabIndex = 3;
            this.button3_3_3.Text = "주문";
            this.button3_3_3.UseVisualStyleBackColor = true;
            this.button3_3_3.Visible = false;
            this.button3_3_3.Click += new System.EventHandler(this.button3_3_3_Click);
            this.button3_3_3.MouseLeave += new System.EventHandler(this.button3_3_3_MouseLeave);
            this.button3_3_3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button3_3_3_MouseMove);
            // 
            // label3_2_1
            // 
            this.label3_2_1.AutoSize = true;
            this.label3_2_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_2_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(202)))), ((int)(((byte)(224)))));
            this.label3_2_1.Location = new System.Drawing.Point(15, 95);
            this.label3_2_1.Name = "label3_2_1";
            this.label3_2_1.Size = new System.Drawing.Size(65, 27);
            this.label3_2_1.TabIndex = 12;
            this.label3_2_1.Text = "사 용";
            // 
            // dataGridView3_2_1
            // 
            this.dataGridView3_2_1.AllowUserToAddRows = false;
            this.dataGridView3_2_1.AllowUserToDeleteRows = false;
            this.dataGridView3_2_1.AllowUserToResizeColumns = false;
            this.dataGridView3_2_1.AllowUserToResizeRows = false;
            this.dataGridView3_2_1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3_2_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView3_2_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3_2_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dataGridView3_2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView3_2_1.Location = new System.Drawing.Point(8, 128);
            this.dataGridView3_2_1.Name = "dataGridView3_2_1";
            this.dataGridView3_2_1.RowHeadersVisible = false;
            this.dataGridView3_2_1.RowTemplate.Height = 23;
            this.dataGridView3_2_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3_2_1.Size = new System.Drawing.Size(610, 500);
            this.dataGridView3_2_1.TabIndex = 6;
            this.dataGridView3_2_1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_2_1_CellContentClick);
            this.dataGridView3_2_1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_2_1_ColumnHeaderMouseClick);
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column11.DefaultCellStyle = dataGridViewCellStyle11;
            this.Column11.HeaderText = "제품코드";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column12.DefaultCellStyle = dataGridViewCellStyle12;
            this.Column12.HeaderText = "제품명";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column13.DefaultCellStyle = dataGridViewCellStyle13;
            this.Column13.HeaderText = "재고";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.NullValue = false;
            this.Column14.DefaultCellStyle = dataGridViewCellStyle14;
            this.Column14.HeaderText = "선택";
            this.Column14.Name = "Column14";
            this.Column14.Width = 50;
            // 
            // dataGridView3_3_1
            // 
            this.dataGridView3_3_1.AllowUserToAddRows = false;
            this.dataGridView3_3_1.AllowUserToDeleteRows = false;
            this.dataGridView3_3_1.AllowUserToResizeColumns = false;
            this.dataGridView3_3_1.AllowUserToResizeRows = false;
            this.dataGridView3_3_1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3_3_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView3_3_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3_3_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column16,
            this.Column18});
            this.dataGridView3_3_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView3_3_1.Location = new System.Drawing.Point(631, 128);
            this.dataGridView3_3_1.Name = "dataGridView3_3_1";
            this.dataGridView3_3_1.RowHeadersVisible = false;
            this.dataGridView3_3_1.RowTemplate.Height = 23;
            this.dataGridView3_3_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3_3_1.Size = new System.Drawing.Size(603, 500);
            this.dataGridView3_3_1.TabIndex = 7;
            this.dataGridView3_3_1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_3_1_CellContentClick);
            this.dataGridView3_3_1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_3_1_ColumnHeaderMouseClick);
            // 
            // Column15
            // 
            this.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column15.DefaultCellStyle = dataGridViewCellStyle15;
            this.Column15.HeaderText = "제품명";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column16.DefaultCellStyle = dataGridViewCellStyle16;
            this.Column16.HeaderText = "수량";
            this.Column16.Name = "Column16";
            // 
            // Column18
            // 
            this.Column18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.NullValue = false;
            this.Column18.DefaultCellStyle = dataGridViewCellStyle17;
            this.Column18.HeaderText = "선택";
            this.Column18.Name = "Column18";
            this.Column18.Width = 50;
            // 
            // label3_3_1
            // 
            this.label3_3_1.AutoSize = true;
            this.label3_3_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_3_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(202)))), ((int)(((byte)(224)))));
            this.label3_3_1.Location = new System.Drawing.Point(639, 95);
            this.label3_3_1.Name = "label3_3_1";
            this.label3_3_1.Size = new System.Drawing.Size(65, 27);
            this.label3_3_1.TabIndex = 7;
            this.label3_3_1.Text = "주 문";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button2.Location = new System.Drawing.Point(88, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 40);
            this.button2.TabIndex = 2;
            this.button2.Text = "근태";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button3.Location = new System.Drawing.Point(159, 69);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 40);
            this.button3.TabIndex = 3;
            this.button3.Text = "재고";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button4.Location = new System.Drawing.Point(230, 67);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(83, 43);
            this.button4.TabIndex = 4;
            this.button4.Text = "관리자";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.dataGridView6);
            this.panel2.Controls.Add(this.panel102);
            this.panel2.Controls.Add(this.button19);
            this.panel2.Controls.Add(this.panel101);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.dataGridView3);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Location = new System.Drawing.Point(325, 148);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1240, 697);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AllowUserToResizeColumns = false;
            this.dataGridView6.AllowUserToResizeRows = false;
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridView6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column22,
            this.Column23,
            this.Column24,
            this.Column37,
            this.Column38});
            this.dataGridView6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView6.Location = new System.Drawing.Point(3, 1);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView6.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridView6.RowHeadersVisible = false;
            this.dataGridView6.RowTemplate.Height = 23;
            this.dataGridView6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView6.Size = new System.Drawing.Size(1153, 261);
            this.dataGridView6.TabIndex = 5;
            // 
            // Column22
            // 
            this.Column22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column22.DefaultCellStyle = dataGridViewCellStyle18;
            this.Column22.HeaderText = "이름";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            // 
            // Column23
            // 
            this.Column23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column23.DefaultCellStyle = dataGridViewCellStyle19;
            this.Column23.HeaderText = "출근시간";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            // 
            // Column24
            // 
            this.Column24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column24.DefaultCellStyle = dataGridViewCellStyle20;
            this.Column24.HeaderText = "퇴근시간";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            // 
            // Column37
            // 
            this.Column37.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column37.DefaultCellStyle = dataGridViewCellStyle21;
            this.Column37.HeaderText = "출근확인";
            this.Column37.Name = "Column37";
            this.Column37.ReadOnly = true;
            // 
            // Column38
            // 
            this.Column38.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column38.DefaultCellStyle = dataGridViewCellStyle22;
            this.Column38.HeaderText = "퇴근확인";
            this.Column38.Name = "Column38";
            this.Column38.ReadOnly = true;
            // 
            // panel102
            // 
            this.panel102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel102.Location = new System.Drawing.Point(691, 267);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(1, 429);
            this.panel102.TabIndex = 29;
            // 
            // button19
            // 
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button19.Location = new System.Drawing.Point(1160, 156);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(78, 65);
            this.button19.TabIndex = 4;
            this.button19.Text = "월차\r\n신청";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            this.button19.MouseLeave += new System.EventHandler(this.button19_MouseLeave);
            this.button19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button19_MouseMove);
            // 
            // panel101
            // 
            this.panel101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel101.Location = new System.Drawing.Point(1, 264);
            this.panel101.Name = "panel101";
            this.panel101.Size = new System.Drawing.Size(1240, 1);
            this.panel101.TabIndex = 173;
            // 
            // button11
            // 
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button11.Location = new System.Drawing.Point(1160, 94);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(78, 50);
            this.button11.TabIndex = 6;
            this.button11.Text = "퇴근";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            this.button11.MouseLeave += new System.EventHandler(this.button11_MouseLeave);
            this.button11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button11_MouseMove);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column19,
            this.Column20,
            this.Column21});
            this.dataGridView3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView3.Location = new System.Drawing.Point(3, 267);
            this.dataGridView3.Name = "dataGridView3";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView3.Size = new System.Drawing.Size(688, 428);
            this.dataGridView3.TabIndex = 5;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column1.DefaultCellStyle = dataGridViewCellStyle24;
            this.Column1.HeaderText = "이름";
            this.Column1.Name = "Column1";
            this.Column1.Width = 69;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column3.DefaultCellStyle = dataGridViewCellStyle25;
            this.Column3.HeaderText = "주민번호";
            this.Column3.Name = "Column3";
            // 
            // Column19
            // 
            this.Column19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column19.DefaultCellStyle = dataGridViewCellStyle26;
            this.Column19.HeaderText = "전화번호";
            this.Column19.Name = "Column19";
            // 
            // Column20
            // 
            this.Column20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column20.DefaultCellStyle = dataGridViewCellStyle27;
            this.Column20.HeaderText = "주소";
            this.Column20.Name = "Column20";
            // 
            // Column21
            // 
            this.Column21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column21.DefaultCellStyle = dataGridViewCellStyle28;
            this.Column21.HeaderText = "예약날짜";
            this.Column21.Name = "Column21";
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button7.Location = new System.Drawing.Point(1160, 32);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(78, 50);
            this.button7.TabIndex = 3;
            this.button7.Text = "출근";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            this.button7.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.button7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.Daycontainer);
            this.panel13.Controls.Add(this.label13);
            this.panel13.Controls.Add(this.button18);
            this.panel13.Controls.Add(this.label16);
            this.panel13.Controls.Add(this.label14);
            this.panel13.Controls.Add(this.label15);
            this.panel13.Controls.Add(this.label17);
            this.panel13.Controls.Add(this.label18);
            this.panel13.Controls.Add(this.label19);
            this.panel13.Controls.Add(this.label20);
            this.panel13.Controls.Add(this.button17);
            this.panel13.Location = new System.Drawing.Point(692, 266);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(546, 429);
            this.panel13.TabIndex = 5;
            this.panel13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel13_MouseClick);
            // 
            // Daycontainer
            // 
            this.Daycontainer.Controls.Add(this.panel15);
            this.Daycontainer.Controls.Add(this.panel16);
            this.Daycontainer.Controls.Add(this.panel17);
            this.Daycontainer.Controls.Add(this.panel18);
            this.Daycontainer.Controls.Add(this.panel19);
            this.Daycontainer.Controls.Add(this.panel21);
            this.Daycontainer.Controls.Add(this.panel20);
            this.Daycontainer.Controls.Add(this.panel29);
            this.Daycontainer.Controls.Add(this.panel42);
            this.Daycontainer.Controls.Add(this.panel41);
            this.Daycontainer.Controls.Add(this.panel40);
            this.Daycontainer.Controls.Add(this.panel39);
            this.Daycontainer.Controls.Add(this.panel38);
            this.Daycontainer.Controls.Add(this.panel37);
            this.Daycontainer.Controls.Add(this.panel36);
            this.Daycontainer.Controls.Add(this.panel35);
            this.Daycontainer.Controls.Add(this.panel34);
            this.Daycontainer.Controls.Add(this.panel33);
            this.Daycontainer.Controls.Add(this.panel32);
            this.Daycontainer.Controls.Add(this.panel31);
            this.Daycontainer.Controls.Add(this.panel30);
            this.Daycontainer.Controls.Add(this.panel43);
            this.Daycontainer.Controls.Add(this.panel56);
            this.Daycontainer.Controls.Add(this.panel55);
            this.Daycontainer.Controls.Add(this.panel54);
            this.Daycontainer.Controls.Add(this.panel53);
            this.Daycontainer.Controls.Add(this.panel52);
            this.Daycontainer.Controls.Add(this.panel51);
            this.Daycontainer.Controls.Add(this.panel50);
            this.Daycontainer.Controls.Add(this.panel49);
            this.Daycontainer.Controls.Add(this.panel48);
            this.Daycontainer.Controls.Add(this.panel47);
            this.Daycontainer.Controls.Add(this.panel46);
            this.Daycontainer.Controls.Add(this.panel45);
            this.Daycontainer.Controls.Add(this.panel44);
            this.Daycontainer.Controls.Add(this.panel22);
            this.Daycontainer.Controls.Add(this.panel28);
            this.Daycontainer.Controls.Add(this.panel27);
            this.Daycontainer.Controls.Add(this.panel26);
            this.Daycontainer.Controls.Add(this.panel25);
            this.Daycontainer.Controls.Add(this.panel24);
            this.Daycontainer.Controls.Add(this.panel23);
            this.Daycontainer.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Daycontainer.Location = new System.Drawing.Point(1, 91);
            this.Daycontainer.Name = "Daycontainer";
            this.Daycontainer.Size = new System.Drawing.Size(544, 337);
            this.Daycontainer.TabIndex = 43;
            // 
            // panel15
            // 
            this.panel15.AutoSize = true;
            this.panel15.BackColor = System.Drawing.SystemColors.Info;
            this.panel15.Location = new System.Drawing.Point(3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(0, 0);
            this.panel15.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.AutoSize = true;
            this.panel16.BackColor = System.Drawing.SystemColors.Info;
            this.panel16.Location = new System.Drawing.Point(9, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(0, 0);
            this.panel16.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.AutoSize = true;
            this.panel17.BackColor = System.Drawing.SystemColors.Info;
            this.panel17.Location = new System.Drawing.Point(15, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(0, 0);
            this.panel17.TabIndex = 2;
            // 
            // panel18
            // 
            this.panel18.AutoSize = true;
            this.panel18.BackColor = System.Drawing.SystemColors.Info;
            this.panel18.Location = new System.Drawing.Point(21, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(0, 0);
            this.panel18.TabIndex = 3;
            // 
            // panel19
            // 
            this.panel19.AutoSize = true;
            this.panel19.BackColor = System.Drawing.SystemColors.Info;
            this.panel19.Location = new System.Drawing.Point(27, 3);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(0, 0);
            this.panel19.TabIndex = 4;
            // 
            // panel21
            // 
            this.panel21.AutoSize = true;
            this.panel21.BackColor = System.Drawing.SystemColors.Info;
            this.panel21.Location = new System.Drawing.Point(33, 3);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(0, 0);
            this.panel21.TabIndex = 6;
            // 
            // panel20
            // 
            this.panel20.AutoSize = true;
            this.panel20.BackColor = System.Drawing.SystemColors.Info;
            this.panel20.Location = new System.Drawing.Point(39, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(0, 0);
            this.panel20.TabIndex = 5;
            // 
            // panel29
            // 
            this.panel29.AutoSize = true;
            this.panel29.BackColor = System.Drawing.SystemColors.Info;
            this.panel29.Location = new System.Drawing.Point(45, 3);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(0, 0);
            this.panel29.TabIndex = 14;
            // 
            // panel42
            // 
            this.panel42.AutoSize = true;
            this.panel42.BackColor = System.Drawing.SystemColors.Info;
            this.panel42.Location = new System.Drawing.Point(51, 3);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(0, 0);
            this.panel42.TabIndex = 22;
            // 
            // panel41
            // 
            this.panel41.AutoSize = true;
            this.panel41.BackColor = System.Drawing.SystemColors.Info;
            this.panel41.Location = new System.Drawing.Point(57, 3);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(0, 0);
            this.panel41.TabIndex = 23;
            // 
            // panel40
            // 
            this.panel40.AutoSize = true;
            this.panel40.BackColor = System.Drawing.SystemColors.Info;
            this.panel40.Location = new System.Drawing.Point(63, 3);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(0, 0);
            this.panel40.TabIndex = 24;
            // 
            // panel39
            // 
            this.panel39.AutoSize = true;
            this.panel39.BackColor = System.Drawing.SystemColors.Info;
            this.panel39.Location = new System.Drawing.Point(69, 3);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(0, 0);
            this.panel39.TabIndex = 25;
            // 
            // panel38
            // 
            this.panel38.AutoSize = true;
            this.panel38.BackColor = System.Drawing.SystemColors.Info;
            this.panel38.Location = new System.Drawing.Point(75, 3);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(0, 0);
            this.panel38.TabIndex = 27;
            // 
            // panel37
            // 
            this.panel37.AutoSize = true;
            this.panel37.BackColor = System.Drawing.SystemColors.Info;
            this.panel37.Location = new System.Drawing.Point(81, 3);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(0, 0);
            this.panel37.TabIndex = 26;
            // 
            // panel36
            // 
            this.panel36.AutoSize = true;
            this.panel36.BackColor = System.Drawing.SystemColors.Info;
            this.panel36.Location = new System.Drawing.Point(87, 3);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(0, 0);
            this.panel36.TabIndex = 21;
            // 
            // panel35
            // 
            this.panel35.AutoSize = true;
            this.panel35.BackColor = System.Drawing.SystemColors.Info;
            this.panel35.Location = new System.Drawing.Point(93, 3);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(0, 0);
            this.panel35.TabIndex = 19;
            // 
            // panel34
            // 
            this.panel34.AutoSize = true;
            this.panel34.BackColor = System.Drawing.SystemColors.Info;
            this.panel34.Location = new System.Drawing.Point(99, 3);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(0, 0);
            this.panel34.TabIndex = 20;
            // 
            // panel33
            // 
            this.panel33.AutoSize = true;
            this.panel33.BackColor = System.Drawing.SystemColors.Info;
            this.panel33.Location = new System.Drawing.Point(105, 3);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(0, 0);
            this.panel33.TabIndex = 18;
            // 
            // panel32
            // 
            this.panel32.AutoSize = true;
            this.panel32.BackColor = System.Drawing.SystemColors.Info;
            this.panel32.Location = new System.Drawing.Point(111, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(0, 0);
            this.panel32.TabIndex = 17;
            // 
            // panel31
            // 
            this.panel31.AutoSize = true;
            this.panel31.BackColor = System.Drawing.SystemColors.Info;
            this.panel31.Location = new System.Drawing.Point(117, 3);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(0, 0);
            this.panel31.TabIndex = 16;
            // 
            // panel30
            // 
            this.panel30.AutoSize = true;
            this.panel30.BackColor = System.Drawing.SystemColors.Info;
            this.panel30.Location = new System.Drawing.Point(123, 3);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(0, 0);
            this.panel30.TabIndex = 15;
            // 
            // panel43
            // 
            this.panel43.AutoSize = true;
            this.panel43.BackColor = System.Drawing.SystemColors.Info;
            this.panel43.Location = new System.Drawing.Point(129, 3);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(0, 0);
            this.panel43.TabIndex = 28;
            // 
            // panel56
            // 
            this.panel56.AutoSize = true;
            this.panel56.BackColor = System.Drawing.SystemColors.Info;
            this.panel56.Location = new System.Drawing.Point(135, 3);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(0, 0);
            this.panel56.TabIndex = 29;
            // 
            // panel55
            // 
            this.panel55.AutoSize = true;
            this.panel55.BackColor = System.Drawing.SystemColors.Info;
            this.panel55.Location = new System.Drawing.Point(141, 3);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(0, 0);
            this.panel55.TabIndex = 30;
            // 
            // panel54
            // 
            this.panel54.AutoSize = true;
            this.panel54.BackColor = System.Drawing.SystemColors.Info;
            this.panel54.Location = new System.Drawing.Point(147, 3);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(0, 0);
            this.panel54.TabIndex = 31;
            // 
            // panel53
            // 
            this.panel53.AutoSize = true;
            this.panel53.BackColor = System.Drawing.SystemColors.Info;
            this.panel53.Location = new System.Drawing.Point(153, 3);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(0, 0);
            this.panel53.TabIndex = 32;
            // 
            // panel52
            // 
            this.panel52.AutoSize = true;
            this.panel52.BackColor = System.Drawing.SystemColors.Info;
            this.panel52.Location = new System.Drawing.Point(159, 3);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(0, 0);
            this.panel52.TabIndex = 34;
            // 
            // panel51
            // 
            this.panel51.AutoSize = true;
            this.panel51.BackColor = System.Drawing.SystemColors.Info;
            this.panel51.Location = new System.Drawing.Point(165, 3);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(0, 0);
            this.panel51.TabIndex = 33;
            // 
            // panel50
            // 
            this.panel50.AutoSize = true;
            this.panel50.BackColor = System.Drawing.SystemColors.Info;
            this.panel50.Location = new System.Drawing.Point(171, 3);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(0, 0);
            this.panel50.TabIndex = 35;
            // 
            // panel49
            // 
            this.panel49.AutoSize = true;
            this.panel49.BackColor = System.Drawing.SystemColors.Info;
            this.panel49.Location = new System.Drawing.Point(177, 3);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(0, 0);
            this.panel49.TabIndex = 40;
            // 
            // panel48
            // 
            this.panel48.AutoSize = true;
            this.panel48.BackColor = System.Drawing.SystemColors.Info;
            this.panel48.Location = new System.Drawing.Point(183, 3);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(0, 0);
            this.panel48.TabIndex = 41;
            // 
            // panel47
            // 
            this.panel47.AutoSize = true;
            this.panel47.BackColor = System.Drawing.SystemColors.Info;
            this.panel47.Location = new System.Drawing.Point(189, 3);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(0, 0);
            this.panel47.TabIndex = 39;
            // 
            // panel46
            // 
            this.panel46.AutoSize = true;
            this.panel46.BackColor = System.Drawing.SystemColors.Info;
            this.panel46.Location = new System.Drawing.Point(195, 3);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(0, 0);
            this.panel46.TabIndex = 38;
            // 
            // panel45
            // 
            this.panel45.AutoSize = true;
            this.panel45.BackColor = System.Drawing.SystemColors.Info;
            this.panel45.Location = new System.Drawing.Point(201, 3);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(0, 0);
            this.panel45.TabIndex = 37;
            // 
            // panel44
            // 
            this.panel44.AutoSize = true;
            this.panel44.BackColor = System.Drawing.SystemColors.Info;
            this.panel44.Location = new System.Drawing.Point(207, 3);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(0, 0);
            this.panel44.TabIndex = 36;
            // 
            // panel22
            // 
            this.panel22.AutoSize = true;
            this.panel22.BackColor = System.Drawing.SystemColors.Info;
            this.panel22.Location = new System.Drawing.Point(213, 3);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(0, 0);
            this.panel22.TabIndex = 7;
            // 
            // panel28
            // 
            this.panel28.AutoSize = true;
            this.panel28.BackColor = System.Drawing.SystemColors.Info;
            this.panel28.Location = new System.Drawing.Point(219, 3);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(0, 0);
            this.panel28.TabIndex = 12;
            // 
            // panel27
            // 
            this.panel27.AutoSize = true;
            this.panel27.BackColor = System.Drawing.SystemColors.Info;
            this.panel27.Location = new System.Drawing.Point(225, 3);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(0, 0);
            this.panel27.TabIndex = 13;
            // 
            // panel26
            // 
            this.panel26.AutoSize = true;
            this.panel26.BackColor = System.Drawing.SystemColors.Info;
            this.panel26.Location = new System.Drawing.Point(231, 3);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(0, 0);
            this.panel26.TabIndex = 11;
            // 
            // panel25
            // 
            this.panel25.AutoSize = true;
            this.panel25.BackColor = System.Drawing.SystemColors.Info;
            this.panel25.Location = new System.Drawing.Point(237, 3);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(0, 0);
            this.panel25.TabIndex = 10;
            // 
            // panel24
            // 
            this.panel24.AutoSize = true;
            this.panel24.BackColor = System.Drawing.SystemColors.Info;
            this.panel24.Location = new System.Drawing.Point(243, 3);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(0, 0);
            this.panel24.TabIndex = 9;
            // 
            // panel23
            // 
            this.panel23.AutoSize = true;
            this.panel23.BackColor = System.Drawing.SystemColors.Info;
            this.panel23.Location = new System.Drawing.Point(249, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(0, 0);
            this.panel23.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("G마켓 산스 TTF Bold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(202, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(182, 27);
            this.label13.TabIndex = 42;
            this.label13.Text = "Month YEAR";
            // 
            // button18
            // 
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.BorderSize = 0;
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button18.Location = new System.Drawing.Point(37, 17);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(87, 39);
            this.button18.TabIndex = 41;
            this.button18.Text = "지난달";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click_1);
            this.button18.MouseLeave += new System.EventHandler(this.button18_MouseLeave);
            this.button18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button18_MouseMove);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(32, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 27);
            this.label16.TabIndex = 21;
            this.label16.Text = "일";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(484, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 27);
            this.label14.TabIndex = 20;
            this.label14.Text = "토";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(406, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 27);
            this.label15.TabIndex = 19;
            this.label15.Text = "금";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(330, 59);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 27);
            this.label17.TabIndex = 18;
            this.label17.Text = "목";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(254, 59);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 27);
            this.label18.TabIndex = 17;
            this.label18.Text = "수";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(180, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 27);
            this.label19.TabIndex = 16;
            this.label19.Text = "화";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(105, 59);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 27);
            this.label20.TabIndex = 15;
            this.label20.Text = "월";
            // 
            // button17
            // 
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button17.Location = new System.Drawing.Point(411, 17);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(87, 39);
            this.button17.TabIndex = 40;
            this.button17.Text = "다음달";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click_1);
            this.button17.MouseLeave += new System.EventHandler(this.button17_MouseLeave);
            this.button17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button17_MouseMove);
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.button4_6);
            this.panel4.Controls.Add(this.button4_1);
            this.panel4.Controls.Add(this.dataGridView4_1);
            this.panel4.Controls.Add(this.label4_1_1);
            this.panel4.Controls.Add(this.panel119);
            this.panel4.Controls.Add(this.label63);
            this.panel4.Controls.Add(this.panel118);
            this.panel4.Controls.Add(this.panel117);
            this.panel4.Controls.Add(this.label4_1_6);
            this.panel4.Controls.Add(this.label4_1_5);
            this.panel4.Controls.Add(this.panel115);
            this.panel4.Controls.Add(this.label4_1_4);
            this.panel4.Controls.Add(this.panel113);
            this.panel4.Controls.Add(this.label4_1_3);
            this.panel4.Controls.Add(this.panel112);
            this.panel4.Controls.Add(this.label4_1_2);
            this.panel4.Controls.Add(this.panel111);
            this.panel4.Controls.Add(this.panel12);
            this.panel4.Controls.Add(this.panel14);
            this.panel4.Controls.Add(this.tabControl2);
            this.panel4.Controls.Add(this.button4_1_1);
            this.panel4.Controls.Add(this.textBox4_1_6);
            this.panel4.Controls.Add(this.label4_6);
            this.panel4.Controls.Add(this.label4_1);
            this.panel4.Controls.Add(this.textBox4_1_5);
            this.panel4.Controls.Add(this.label4_2);
            this.panel4.Controls.Add(this.label4_5);
            this.panel4.Controls.Add(this.label4_3);
            this.panel4.Controls.Add(this.panel4_1_1);
            this.panel4.Controls.Add(this.label4_4);
            this.panel4.Controls.Add(this.textBox4_1_4);
            this.panel4.Controls.Add(this.textBox4_1_1);
            this.panel4.Controls.Add(this.textBox4_1_3);
            this.panel4.Controls.Add(this.textBox4_1_2);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(325, 148);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3000, 697);
            this.panel4.TabIndex = 6;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            this.panel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel4_MouseClick);
            // 
            // button4_6
            // 
            this.button4_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_6.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_6.FlatAppearance.BorderSize = 0;
            this.button4_6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_6.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button4_6.Location = new System.Drawing.Point(3, 645);
            this.button4_6.Name = "button4_6";
            this.button4_6.Size = new System.Drawing.Size(104, 46);
            this.button4_6.TabIndex = 178;
            this.button4_6.Text = "삭제";
            this.button4_6.UseVisualStyleBackColor = true;
            this.button4_6.Click += new System.EventHandler(this.button4_6_Click);
            this.button4_6.MouseLeave += new System.EventHandler(this.button4_6_MouseLeave);
            this.button4_6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_6_MouseMove);
            // 
            // button4_1
            // 
            this.button4_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_1.FlatAppearance.BorderSize = 0;
            this.button4_1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button4_1.Location = new System.Drawing.Point(186, 645);
            this.button4_1.Name = "button4_1";
            this.button4_1.Size = new System.Drawing.Size(104, 46);
            this.button4_1.TabIndex = 29;
            this.button4_1.Text = "신규등록";
            this.button4_1.UseVisualStyleBackColor = true;
            this.button4_1.Click += new System.EventHandler(this.button4_1_Click);
            this.button4_1.MouseLeave += new System.EventHandler(this.button4_1_MouseLeave);
            this.button4_1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_1_MouseMove);
            // 
            // dataGridView4_1
            // 
            this.dataGridView4_1.AllowUserToAddRows = false;
            this.dataGridView4_1.AllowUserToDeleteRows = false;
            this.dataGridView4_1.AllowUserToResizeColumns = false;
            this.dataGridView4_1.AllowUserToResizeRows = false;
            this.dataGridView4_1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column10});
            this.dataGridView4_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4_1.Location = new System.Drawing.Point(2, 2);
            this.dataGridView4_1.Name = "dataGridView4_1";
            this.dataGridView4_1.RowHeadersVisible = false;
            this.dataGridView4_1.RowTemplate.Height = 23;
            this.dataGridView4_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_1.Size = new System.Drawing.Size(293, 692);
            this.dataGridView4_1.TabIndex = 5;
            this.dataGridView4_1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_1_CellClick);
            this.dataGridView4_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView4_1_MouseClick);
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.Column4.DefaultCellStyle = dataGridViewCellStyle30;
            this.Column4.HeaderText = "직원이름";
            this.Column4.Name = "Column4";
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column10.DefaultCellStyle = dataGridViewCellStyle31;
            this.Column10.HeaderText = "직급";
            this.Column10.Name = "Column10";
            // 
            // label4_1_1
            // 
            this.label4_1_1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_1.Location = new System.Drawing.Point(445, 32);
            this.label4_1_1.Name = "label4_1_1";
            this.label4_1_1.Size = new System.Drawing.Size(186, 29);
            this.label4_1_1.TabIndex = 177;
            // 
            // panel119
            // 
            this.panel119.BackColor = System.Drawing.Color.Black;
            this.panel119.Location = new System.Drawing.Point(1407, 362);
            this.panel119.Name = "panel119";
            this.panel119.Size = new System.Drawing.Size(186, 1);
            this.panel119.TabIndex = 176;
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(1407, 334);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(186, 29);
            this.label63.TabIndex = 175;
            // 
            // panel118
            // 
            this.panel118.BackColor = System.Drawing.Color.Black;
            this.panel118.Location = new System.Drawing.Point(805, 176);
            this.panel118.Name = "panel118";
            this.panel118.Size = new System.Drawing.Size(186, 1);
            this.panel118.TabIndex = 174;
            // 
            // panel117
            // 
            this.panel117.BackColor = System.Drawing.Color.Black;
            this.panel117.Location = new System.Drawing.Point(805, 117);
            this.panel117.Name = "panel117";
            this.panel117.Size = new System.Drawing.Size(186, 1);
            this.panel117.TabIndex = 44;
            // 
            // label4_1_6
            // 
            this.label4_1_6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_6.Location = new System.Drawing.Point(805, 148);
            this.label4_1_6.Name = "label4_1_6";
            this.label4_1_6.Size = new System.Drawing.Size(186, 29);
            this.label4_1_6.TabIndex = 173;
            // 
            // label4_1_5
            // 
            this.label4_1_5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_5.Location = new System.Drawing.Point(805, 89);
            this.label4_1_5.Name = "label4_1_5";
            this.label4_1_5.Size = new System.Drawing.Size(186, 29);
            this.label4_1_5.TabIndex = 43;
            // 
            // panel115
            // 
            this.panel115.BackColor = System.Drawing.Color.Black;
            this.panel115.Location = new System.Drawing.Point(805, 57);
            this.panel115.Name = "panel115";
            this.panel115.Size = new System.Drawing.Size(186, 1);
            this.panel115.TabIndex = 42;
            // 
            // label4_1_4
            // 
            this.label4_1_4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_4.Location = new System.Drawing.Point(805, 29);
            this.label4_1_4.Name = "label4_1_4";
            this.label4_1_4.Size = new System.Drawing.Size(186, 29);
            this.label4_1_4.TabIndex = 41;
            // 
            // panel113
            // 
            this.panel113.BackColor = System.Drawing.Color.Black;
            this.panel113.Location = new System.Drawing.Point(445, 176);
            this.panel113.Name = "panel113";
            this.panel113.Size = new System.Drawing.Size(186, 1);
            this.panel113.TabIndex = 40;
            // 
            // label4_1_3
            // 
            this.label4_1_3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_3.Location = new System.Drawing.Point(445, 148);
            this.label4_1_3.Name = "label4_1_3";
            this.label4_1_3.Size = new System.Drawing.Size(186, 29);
            this.label4_1_3.TabIndex = 39;
            // 
            // panel112
            // 
            this.panel112.BackColor = System.Drawing.Color.Black;
            this.panel112.Location = new System.Drawing.Point(445, 117);
            this.panel112.Name = "panel112";
            this.panel112.Size = new System.Drawing.Size(186, 1);
            this.panel112.TabIndex = 38;
            // 
            // label4_1_2
            // 
            this.label4_1_2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label4_1_2.Location = new System.Drawing.Point(445, 89);
            this.label4_1_2.Name = "label4_1_2";
            this.label4_1_2.Size = new System.Drawing.Size(186, 29);
            this.label4_1_2.TabIndex = 37;
            // 
            // panel111
            // 
            this.panel111.BackColor = System.Drawing.Color.Black;
            this.panel111.Location = new System.Drawing.Point(444, 61);
            this.panel111.Name = "panel111";
            this.panel111.Size = new System.Drawing.Size(186, 1);
            this.panel111.TabIndex = 36;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel12.Location = new System.Drawing.Point(298, 250);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(939, 1);
            this.panel12.TabIndex = 27;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel14.Location = new System.Drawing.Point(297, -3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1, 697);
            this.panel14.TabIndex = 28;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl2.Location = new System.Drawing.Point(297, 250);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(938, 443);
            this.tabControl2.TabIndex = 4;
            this.tabControl2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl2_MouseClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView4_2);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(930, 405);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "월급내역";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView4_2
            // 
            this.dataGridView4_2.AllowUserToAddRows = false;
            this.dataGridView4_2.AllowUserToDeleteRows = false;
            this.dataGridView4_2.AllowUserToResizeRows = false;
            this.dataGridView4_2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column32,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column31,
            this.Column30});
            this.dataGridView4_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4_2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4_2.Name = "dataGridView4_2";
            this.dataGridView4_2.RowHeadersVisible = false;
            this.dataGridView4_2.RowTemplate.Height = 23;
            this.dataGridView4_2.Size = new System.Drawing.Size(924, 399);
            this.dataGridView4_2.TabIndex = 0;
            this.dataGridView4_2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_2_CellContentClick);
            this.dataGridView4_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView4_2_MouseClick);
            // 
            // Column32
            // 
            this.Column32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column32.DefaultCellStyle = dataGridViewCellStyle32;
            this.Column32.HeaderText = "날짜";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            // 
            // Column26
            // 
            this.Column26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column26.DefaultCellStyle = dataGridViewCellStyle33;
            this.Column26.HeaderText = "근무일수";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column27
            // 
            this.Column27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column27.DefaultCellStyle = dataGridViewCellStyle34;
            this.Column27.HeaderText = "근무시간";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column28
            // 
            this.Column28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column28.DefaultCellStyle = dataGridViewCellStyle35;
            this.Column28.HeaderText = "은행명";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column29
            // 
            this.Column29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column29.DefaultCellStyle = dataGridViewCellStyle36;
            this.Column29.HeaderText = "계좌번호";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column31
            // 
            this.Column31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column31.DefaultCellStyle = dataGridViewCellStyle37;
            this.Column31.HeaderText = "예금주";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            this.Column31.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Column30
            // 
            this.Column30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column30.DefaultCellStyle = dataGridViewCellStyle38;
            this.Column30.HeaderText = "확인";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column30.Width = 69;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView7);
            this.tabPage4.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(930, 405);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "근태조회";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.AllowUserToDeleteRows = false;
            this.dataGridView7.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column25,
            this.Column52,
            this.Column40,
            this.Column53,
            this.Column54});
            this.dataGridView7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView7.Location = new System.Drawing.Point(3, 3);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowHeadersVisible = false;
            this.dataGridView7.RowTemplate.Height = 23;
            this.dataGridView7.Size = new System.Drawing.Size(924, 399);
            this.dataGridView7.TabIndex = 0;
            // 
            // Column25
            // 
            this.Column25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column25.DefaultCellStyle = dataGridViewCellStyle39;
            this.Column25.HeaderText = "날짜";
            this.Column25.Name = "Column25";
            // 
            // Column52
            // 
            this.Column52.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column52.DefaultCellStyle = dataGridViewCellStyle40;
            this.Column52.HeaderText = "퇴근확인";
            this.Column52.Name = "Column52";
            // 
            // Column40
            // 
            this.Column40.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column40.DefaultCellStyle = dataGridViewCellStyle41;
            this.Column40.HeaderText = "출근확인";
            this.Column40.Name = "Column40";
            // 
            // Column53
            // 
            this.Column53.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column53.DefaultCellStyle = dataGridViewCellStyle42;
            this.Column53.HeaderText = "근무시간";
            this.Column53.Name = "Column53";
            // 
            // Column54
            // 
            this.Column54.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column54.DefaultCellStyle = dataGridViewCellStyle43;
            this.Column54.HeaderText = "근무일수";
            this.Column54.Name = "Column54";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel4_2);
            this.tabPage5.Location = new System.Drawing.Point(4, 34);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(930, 405);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "재직증명서";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel4_2
            // 
            this.panel4_2.AutoScroll = true;
            this.panel4_2.BackColor = System.Drawing.Color.White;
            this.panel4_2.Controls.Add(this.textBox19);
            this.panel4_2.Controls.Add(this.textBox18);
            this.panel4_2.Controls.Add(this.textBox17);
            this.panel4_2.Controls.Add(this.textBox16);
            this.panel4_2.Controls.Add(this.textBox15);
            this.panel4_2.Controls.Add(this.textBox14);
            this.panel4_2.Controls.Add(this.textBox13);
            this.panel4_2.Controls.Add(this.textBox12);
            this.panel4_2.Controls.Add(this.textBox3);
            this.panel4_2.Controls.Add(this.panel132);
            this.panel4_2.Controls.Add(this.label70);
            this.panel4_2.Controls.Add(this.panel131);
            this.panel4_2.Controls.Add(this.label69);
            this.panel4_2.Controls.Add(this.panel130);
            this.panel4_2.Controls.Add(this.label68);
            this.panel4_2.Controls.Add(this.panel129);
            this.panel4_2.Controls.Add(this.label64);
            this.panel4_2.Controls.Add(this.panel128);
            this.panel4_2.Controls.Add(this.label62);
            this.panel4_2.Controls.Add(this.panel127);
            this.panel4_2.Controls.Add(this.label61);
            this.panel4_2.Controls.Add(this.panel126);
            this.panel4_2.Controls.Add(this.label59);
            this.panel4_2.Controls.Add(this.panel125);
            this.panel4_2.Controls.Add(this.label57);
            this.panel4_2.Controls.Add(this.panel124);
            this.panel4_2.Controls.Add(this.label52);
            this.panel4_2.Controls.Add(this.label51);
            this.panel4_2.Controls.Add(this.label50);
            this.panel4_2.Controls.Add(this.label48);
            this.panel4_2.Controls.Add(this.label33);
            this.panel4_2.Controls.Add(this.panel120);
            this.panel4_2.Controls.Add(this.label32);
            this.panel4_2.Controls.Add(this.label31);
            this.panel4_2.Controls.Add(this.label28);
            this.panel4_2.Controls.Add(this.label27);
            this.panel4_2.Controls.Add(this.label26);
            this.panel4_2.Controls.Add(this.label25);
            this.panel4_2.Controls.Add(this.label24);
            this.panel4_2.Controls.Add(this.label22);
            this.panel4_2.Controls.Add(this.label30);
            this.panel4_2.Controls.Add(this.label71);
            this.panel4_2.Controls.Add(this.button4_2);
            this.panel4_2.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel4_2.Location = new System.Drawing.Point(3, 3);
            this.panel4_2.Name = "panel4_2";
            this.panel4_2.Size = new System.Drawing.Size(927, 412);
            this.panel4_2.TabIndex = 0;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(50, 36);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(206, 31);
            this.textBox19.TabIndex = 107;
            this.textBox19.Visible = false;
            this.textBox19.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(53, 34);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(206, 31);
            this.textBox18.TabIndex = 106;
            this.textBox18.Visible = false;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(50, 34);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(206, 31);
            this.textBox17.TabIndex = 105;
            this.textBox17.Visible = false;
            this.textBox17.TextChanged += new System.EventHandler(this.textBox17_TextChanged);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(53, 34);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(206, 31);
            this.textBox16.TabIndex = 104;
            this.textBox16.Visible = false;
            this.textBox16.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(49, 34);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(206, 31);
            this.textBox15.TabIndex = 103;
            this.textBox15.Visible = false;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(53, 36);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(206, 31);
            this.textBox14.TabIndex = 102;
            this.textBox14.Visible = false;
            this.textBox14.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(50, 32);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(206, 31);
            this.textBox13.TabIndex = 101;
            this.textBox13.Visible = false;
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(48, 39);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(206, 31);
            this.textBox12.TabIndex = 100;
            this.textBox12.Visible = false;
            this.textBox12.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(49, 29);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(206, 31);
            this.textBox3.TabIndex = 99;
            this.textBox3.Visible = false;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // panel132
            // 
            this.panel132.BackColor = System.Drawing.Color.Black;
            this.panel132.Location = new System.Drawing.Point(180, 562);
            this.panel132.Name = "panel132";
            this.panel132.Size = new System.Drawing.Size(650, 1);
            this.panel132.TabIndex = 98;
            // 
            // label70
            // 
            this.label70.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label70.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(180, 533);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(650, 29);
            this.label70.TabIndex = 97;
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label70.Click += new System.EventHandler(this.label70_Click);
            // 
            // panel131
            // 
            this.panel131.BackColor = System.Drawing.Color.Black;
            this.panel131.Location = new System.Drawing.Point(198, 482);
            this.panel131.Name = "panel131";
            this.panel131.Size = new System.Drawing.Size(632, 1);
            this.panel131.TabIndex = 96;
            // 
            // label69
            // 
            this.label69.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label69.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(198, 453);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(632, 29);
            this.label69.TabIndex = 95;
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label69.Click += new System.EventHandler(this.label69_Click);
            // 
            // panel130
            // 
            this.panel130.BackColor = System.Drawing.Color.Black;
            this.panel130.Location = new System.Drawing.Point(180, 402);
            this.panel130.Name = "panel130";
            this.panel130.Size = new System.Drawing.Size(650, 1);
            this.panel130.TabIndex = 94;
            // 
            // label68
            // 
            this.label68.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label68.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(180, 373);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(650, 29);
            this.label68.TabIndex = 93;
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label68.Click += new System.EventHandler(this.label68_Click);
            // 
            // panel129
            // 
            this.panel129.BackColor = System.Drawing.Color.Black;
            this.panel129.Location = new System.Drawing.Point(590, 319);
            this.panel129.Name = "panel129";
            this.panel129.Size = new System.Drawing.Size(240, 1);
            this.panel129.TabIndex = 92;
            // 
            // label64
            // 
            this.label64.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label64.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(590, 290);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(240, 29);
            this.label64.TabIndex = 91;
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label64.Click += new System.EventHandler(this.label64_Click);
            // 
            // panel128
            // 
            this.panel128.BackColor = System.Drawing.Color.Black;
            this.panel128.Location = new System.Drawing.Point(180, 319);
            this.panel128.Name = "panel128";
            this.panel128.Size = new System.Drawing.Size(240, 1);
            this.panel128.TabIndex = 90;
            // 
            // label62
            // 
            this.label62.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label62.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(180, 290);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(240, 29);
            this.label62.TabIndex = 89;
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // panel127
            // 
            this.panel127.BackColor = System.Drawing.Color.Black;
            this.panel127.Location = new System.Drawing.Point(590, 239);
            this.panel127.Name = "panel127";
            this.panel127.Size = new System.Drawing.Size(240, 1);
            this.panel127.TabIndex = 88;
            // 
            // label61
            // 
            this.label61.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label61.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(590, 210);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(240, 29);
            this.label61.TabIndex = 87;
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label61.Click += new System.EventHandler(this.label61_Click);
            // 
            // panel126
            // 
            this.panel126.BackColor = System.Drawing.Color.Black;
            this.panel126.Location = new System.Drawing.Point(180, 239);
            this.panel126.Name = "panel126";
            this.panel126.Size = new System.Drawing.Size(240, 1);
            this.panel126.TabIndex = 86;
            // 
            // label59
            // 
            this.label59.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label59.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(180, 210);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(240, 29);
            this.label59.TabIndex = 85;
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // panel125
            // 
            this.panel125.BackColor = System.Drawing.Color.Black;
            this.panel125.Location = new System.Drawing.Point(586, 160);
            this.panel125.Name = "panel125";
            this.panel125.Size = new System.Drawing.Size(240, 1);
            this.panel125.TabIndex = 84;
            // 
            // label57
            // 
            this.label57.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label57.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(590, 131);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(240, 29);
            this.label57.TabIndex = 83;
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // panel124
            // 
            this.panel124.BackColor = System.Drawing.Color.Black;
            this.panel124.Location = new System.Drawing.Point(180, 160);
            this.panel124.Name = "panel124";
            this.panel124.Size = new System.Drawing.Size(240, 1);
            this.panel124.TabIndex = 82;
            // 
            // label52
            // 
            this.label52.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label52.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(180, 131);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(240, 29);
            this.label52.TabIndex = 81;
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(701, 944);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(156, 25);
            this.label51.TabIndex = 80;
            this.label51.Text = "병원장 OOO  (인)";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(396, 877);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(92, 25);
            this.label50.TabIndex = 79;
            this.label50.Text = "OOO병원";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(352, 770);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(82, 25);
            this.label48.TabIndex = 78;
            this.label48.Text = "오늘 날짜";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(240, 678);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(336, 25);
            this.label33.TabIndex = 77;
            this.label33.Text = "상기와 같이 병원에 재직하고 있음을 증명함.";
            // 
            // panel120
            // 
            this.panel120.BackColor = System.Drawing.Color.Black;
            this.panel120.Location = new System.Drawing.Point(0, 617);
            this.panel120.Name = "panel120";
            this.panel120.Size = new System.Drawing.Size(921, 2);
            this.panel120.TabIndex = 76;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(90, 537);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(44, 25);
            this.label32.TabIndex = 75;
            this.label32.Text = "용도";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(90, 457);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(76, 25);
            this.label31.TabIndex = 74;
            this.label31.Text = "병원주소";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(90, 377);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 25);
            this.label28.TabIndex = 73;
            this.label28.Text = "현주소";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(480, 297);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(44, 25);
            this.label27.TabIndex = 72;
            this.label27.Text = "직위";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(90, 297);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 25);
            this.label26.TabIndex = 71;
            this.label26.Text = "소속";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(480, 217);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 25);
            this.label25.TabIndex = 70;
            this.label25.Text = "E-mail";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(90, 217);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 25);
            this.label24.TabIndex = 69;
            this.label24.Text = "연락처";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(480, 137);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 25);
            this.label22.TabIndex = 68;
            this.label22.Text = "주민번호";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(90, 137);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(44, 25);
            this.label30.TabIndex = 67;
            this.label30.Text = "이름";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(376, 34);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(142, 37);
            this.label71.TabIndex = 66;
            this.label71.Text = "재직증명서";
            // 
            // button4_2
            // 
            this.button4_2.BackColor = System.Drawing.Color.White;
            this.button4_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_2.FlatAppearance.BorderSize = 0;
            this.button4_2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button4_2.Location = new System.Drawing.Point(807, 13);
            this.button4_2.Name = "button4_2";
            this.button4_2.Size = new System.Drawing.Size(101, 37);
            this.button4_2.TabIndex = 2;
            this.button4_2.TabStop = false;
            this.button4_2.Text = "인쇄";
            this.button4_2.UseVisualStyleBackColor = false;
            this.button4_2.MouseLeave += new System.EventHandler(this.button4_2_MouseLeave);
            this.button4_2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_2_MouseMove);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.White;
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Controls.Add(this.dataGridView8);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.dataGridView4_5);
            this.tabPage6.Controls.Add(this.button4_4);
            this.tabPage6.Controls.Add(this.label67);
            this.tabPage6.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage6.Location = new System.Drawing.Point(4, 34);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage6.Size = new System.Drawing.Size(930, 405);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "월/반차 결재";
            // 
            // button15
            // 
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button15.Location = new System.Drawing.Point(802, 162);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(82, 55);
            this.button15.TabIndex = 10;
            this.button15.Text = "반려";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            this.button15.MouseLeave += new System.EventHandler(this.button15_MouseLeave);
            this.button15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button15_MouseMove);
            // 
            // dataGridView8
            // 
            this.dataGridView8.AllowUserToAddRows = false;
            this.dataGridView8.AllowUserToDeleteRows = false;
            this.dataGridView8.AllowUserToResizeRows = false;
            this.dataGridView8.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewCheckBoxColumn2});
            this.dataGridView8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView8.Location = new System.Drawing.Point(30, 236);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.RowHeadersVisible = false;
            this.dataGridView8.RowTemplate.Height = 23;
            this.dataGridView8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView8.Size = new System.Drawing.Size(709, 162);
            this.dataGridView8.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn7.HeaderText = "이름";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 69;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewTextBoxColumn8.HeaderText = "주민번호";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewTextBoxColumn9.HeaderText = "날짜";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewTextBoxColumn10.HeaderText = "월차/반차";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 107;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewTextBoxColumn11.HeaderText = "비고";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle49.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle49.NullValue = false;
            this.dataGridViewCheckBoxColumn2.DefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridViewCheckBoxColumn2.HeaderText = "선택";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Width = 50;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(29, 207);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(146, 24);
            this.label21.TabIndex = 8;
            this.label21.Text = "월차/반차 확인";
            // 
            // dataGridView4_5
            // 
            this.dataGridView4_5.AllowUserToAddRows = false;
            this.dataGridView4_5.AllowUserToDeleteRows = false;
            this.dataGridView4_5.AllowUserToResizeRows = false;
            this.dataGridView4_5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4_5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4_5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.Column17,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.Column39,
            this.dataGridViewCheckBoxColumn1});
            this.dataGridView4_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4_5.Location = new System.Drawing.Point(30, 44);
            this.dataGridView4_5.Name = "dataGridView4_5";
            this.dataGridView4_5.RowHeadersVisible = false;
            this.dataGridView4_5.RowTemplate.Height = 23;
            this.dataGridView4_5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_5.Size = new System.Drawing.Size(709, 162);
            this.dataGridView4_5.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridViewTextBoxColumn3.HeaderText = "이름";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 69;
            // 
            // Column17
            // 
            this.Column17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle51.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column17.DefaultCellStyle = dataGridViewCellStyle51;
            this.Column17.HeaderText = "주민번호";
            this.Column17.Name = "Column17";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle52;
            this.dataGridViewTextBoxColumn1.HeaderText = "날짜";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle53;
            this.dataGridViewTextBoxColumn2.HeaderText = "월차/반차";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 107;
            // 
            // Column39
            // 
            this.Column39.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column39.DefaultCellStyle = dataGridViewCellStyle54;
            this.Column39.HeaderText = "비고";
            this.Column39.Name = "Column39";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle55.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle55.NullValue = false;
            this.dataGridViewCheckBoxColumn1.DefaultCellStyle = dataGridViewCellStyle55;
            this.dataGridViewCheckBoxColumn1.HeaderText = "선택";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Width = 50;
            // 
            // button4_4
            // 
            this.button4_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_4.FlatAppearance.BorderSize = 0;
            this.button4_4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button4_4.Location = new System.Drawing.Point(802, 49);
            this.button4_4.Name = "button4_4";
            this.button4_4.Size = new System.Drawing.Size(82, 40);
            this.button4_4.TabIndex = 7;
            this.button4_4.Text = "결재";
            this.button4_4.UseVisualStyleBackColor = true;
            this.button4_4.Click += new System.EventHandler(this.button4_4_Click);
            this.button4_4.MouseLeave += new System.EventHandler(this.button4_4_MouseLeave);
            this.button4_4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_4_MouseMove);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(29, 13);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(146, 24);
            this.label67.TabIndex = 5;
            this.label67.Text = "월차/반차 결재";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.White;
            this.tabPage7.Controls.Add(this.label23);
            this.tabPage7.Controls.Add(this.dataGridView4_7);
            this.tabPage7.Controls.Add(this.button4_5);
            this.tabPage7.Controls.Add(this.button4_3);
            this.tabPage7.Controls.Add(this.label29);
            this.tabPage7.Controls.Add(this.dataGridView4_6);
            this.tabPage7.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage7.Location = new System.Drawing.Point(4, 34);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(930, 405);
            this.tabPage7.TabIndex = 4;
            this.tabPage7.Text = "제품 결재";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 210);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(120, 25);
            this.label23.TabIndex = 14;
            this.label23.Text = "주문 완료 내역";
            // 
            // dataGridView4_7
            // 
            this.dataGridView4_7.AllowUserToAddRows = false;
            this.dataGridView4_7.AllowUserToDeleteRows = false;
            this.dataGridView4_7.AllowUserToResizeRows = false;
            this.dataGridView4_7.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4_7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4_7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView4_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4_7.Location = new System.Drawing.Point(6, 247);
            this.dataGridView4_7.Name = "dataGridView4_7";
            this.dataGridView4_7.RowHeadersVisible = false;
            this.dataGridView4_7.RowTemplate.Height = 23;
            this.dataGridView4_7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_7.Size = new System.Drawing.Size(906, 150);
            this.dataGridView4_7.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle56.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle56;
            this.dataGridViewTextBoxColumn4.HeaderText = "제품명";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle57;
            this.dataGridViewTextBoxColumn5.HeaderText = "수량";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle58;
            this.dataGridViewTextBoxColumn6.HeaderText = "주문시간";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // button4_5
            // 
            this.button4_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_5.FlatAppearance.BorderSize = 0;
            this.button4_5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button4_5.Location = new System.Drawing.Point(768, 136);
            this.button4_5.Name = "button4_5";
            this.button4_5.Size = new System.Drawing.Size(90, 45);
            this.button4_5.TabIndex = 12;
            this.button4_5.Text = "취소";
            this.button4_5.UseVisualStyleBackColor = true;
            this.button4_5.Click += new System.EventHandler(this.button4_5_Click);
            this.button4_5.MouseLeave += new System.EventHandler(this.button4_5_MouseLeave);
            this.button4_5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_5_MouseMove);
            // 
            // button4_3
            // 
            this.button4_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_3.FlatAppearance.BorderSize = 0;
            this.button4_3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button4_3.Location = new System.Drawing.Point(768, 71);
            this.button4_3.Name = "button4_3";
            this.button4_3.Size = new System.Drawing.Size(90, 45);
            this.button4_3.TabIndex = 11;
            this.button4_3.Text = "주문";
            this.button4_3.UseVisualStyleBackColor = true;
            this.button4_3.Click += new System.EventHandler(this.button4_3_Click);
            this.button4_3.MouseLeave += new System.EventHandler(this.button4_3_MouseLeave);
            this.button4_3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_3_MouseMove);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(1, 3);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(82, 25);
            this.label29.TabIndex = 10;
            this.label29.Text = "물품 결재";
            // 
            // dataGridView4_6
            // 
            this.dataGridView4_6.AllowUserToAddRows = false;
            this.dataGridView4_6.AllowUserToDeleteRows = false;
            this.dataGridView4_6.AllowUserToResizeRows = false;
            this.dataGridView4_6.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4_6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4_6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4_6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column33,
            this.Column34,
            this.Column35,
            this.Column36});
            this.dataGridView4_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4_6.Location = new System.Drawing.Point(6, 31);
            this.dataGridView4_6.Name = "dataGridView4_6";
            this.dataGridView4_6.RowHeadersVisible = false;
            this.dataGridView4_6.RowTemplate.Height = 23;
            this.dataGridView4_6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4_6.Size = new System.Drawing.Size(713, 150);
            this.dataGridView4_6.TabIndex = 9;
            this.dataGridView4_6.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_6_ColumnHeaderMouseClick);
            // 
            // Column33
            // 
            this.Column33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column33.DefaultCellStyle = dataGridViewCellStyle59;
            this.Column33.HeaderText = "제품명";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Width = 85;
            // 
            // Column34
            // 
            this.Column34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle60.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column34.DefaultCellStyle = dataGridViewCellStyle60;
            this.Column34.HeaderText = "수량";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Width = 69;
            // 
            // Column35
            // 
            this.Column35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle61.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column35.DefaultCellStyle = dataGridViewCellStyle61;
            this.Column35.HeaderText = "결재시간";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            // 
            // Column36
            // 
            this.Column36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle62.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle62.NullValue = false;
            this.Column36.DefaultCellStyle = dataGridViewCellStyle62;
            this.Column36.HeaderText = "선택";
            this.Column36.Name = "Column36";
            this.Column36.Width = 50;
            // 
            // button4_1_1
            // 
            this.button4_1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4_1_1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4_1_1.FlatAppearance.BorderSize = 0;
            this.button4_1_1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4_1_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4_1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4_1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button4_1_1.Location = new System.Drawing.Point(926, 201);
            this.button4_1_1.Name = "button4_1_1";
            this.button4_1_1.Size = new System.Drawing.Size(65, 40);
            this.button4_1_1.TabIndex = 19;
            this.button4_1_1.Text = "수정";
            this.button4_1_1.UseVisualStyleBackColor = true;
            this.button4_1_1.Click += new System.EventHandler(this.button4_1_1_Click);
            this.button4_1_1.MouseLeave += new System.EventHandler(this.button4_1_1_MouseLeave_1);
            this.button4_1_1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button4_1_1_MouseMove_1);
            // 
            // textBox4_1_6
            // 
            this.textBox4_1_6.Location = new System.Drawing.Point(2811, 96);
            this.textBox4_1_6.Name = "textBox4_1_6";
            this.textBox4_1_6.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_6.TabIndex = 17;
            this.textBox4_1_6.TextChanged += new System.EventHandler(this.textBox4_1_6_TextChanged);
            // 
            // label4_6
            // 
            this.label4_6.AutoSize = true;
            this.label4_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_6.Location = new System.Drawing.Point(690, 150);
            this.label4_6.Name = "label4_6";
            this.label4_6.Size = new System.Drawing.Size(60, 25);
            this.label4_6.TabIndex = 14;
            this.label4_6.Text = "이메일";
            // 
            // label4_1
            // 
            this.label4_1.AutoSize = true;
            this.label4_1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label4_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_1.Location = new System.Drawing.Point(330, 30);
            this.label4_1.Name = "label4_1";
            this.label4_1.Size = new System.Drawing.Size(44, 25);
            this.label4_1.TabIndex = 3;
            this.label4_1.Text = "이름";
            // 
            // textBox4_1_5
            // 
            this.textBox4_1_5.Location = new System.Drawing.Point(2811, 48);
            this.textBox4_1_5.Name = "textBox4_1_5";
            this.textBox4_1_5.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_5.TabIndex = 13;
            this.textBox4_1_5.TextChanged += new System.EventHandler(this.textBox4_1_5_TextChanged);
            // 
            // label4_2
            // 
            this.label4_2.AutoSize = true;
            this.label4_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_2.Location = new System.Drawing.Point(330, 90);
            this.label4_2.Name = "label4_2";
            this.label4_2.Size = new System.Drawing.Size(76, 25);
            this.label4_2.TabIndex = 4;
            this.label4_2.Text = "주민번호";
            // 
            // label4_5
            // 
            this.label4_5.AutoSize = true;
            this.label4_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_5.Location = new System.Drawing.Point(690, 90);
            this.label4_5.Name = "label4_5";
            this.label4_5.Size = new System.Drawing.Size(60, 25);
            this.label4_5.TabIndex = 12;
            this.label4_5.Text = "입사일";
            // 
            // label4_3
            // 
            this.label4_3.AutoSize = true;
            this.label4_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_3.Location = new System.Drawing.Point(330, 150);
            this.label4_3.Name = "label4_3";
            this.label4_3.Size = new System.Drawing.Size(44, 25);
            this.label4_3.TabIndex = 5;
            this.label4_3.Text = "주소";
            // 
            // panel4_1_1
            // 
            this.panel4_1_1.Location = new System.Drawing.Point(1016, 13);
            this.panel4_1_1.Name = "panel4_1_1";
            this.panel4_1_1.Size = new System.Drawing.Size(218, 228);
            this.panel4_1_1.TabIndex = 11;
            // 
            // label4_4
            // 
            this.label4_4.AutoSize = true;
            this.label4_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_4.Location = new System.Drawing.Point(690, 30);
            this.label4_4.Name = "label4_4";
            this.label4_4.Size = new System.Drawing.Size(76, 25);
            this.label4_4.TabIndex = 6;
            this.label4_4.Text = "전화번호";
            // 
            // textBox4_1_4
            // 
            this.textBox4_1_4.Location = new System.Drawing.Point(2474, 197);
            this.textBox4_1_4.Name = "textBox4_1_4";
            this.textBox4_1_4.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_4.TabIndex = 10;
            this.textBox4_1_4.TextChanged += new System.EventHandler(this.textBox4_1_4_TextChanged);
            // 
            // textBox4_1_1
            // 
            this.textBox4_1_1.Location = new System.Drawing.Point(2474, 48);
            this.textBox4_1_1.Name = "textBox4_1_1";
            this.textBox4_1_1.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_1.TabIndex = 7;
            this.textBox4_1_1.TextChanged += new System.EventHandler(this.textBox4_1_1_TextChanged);
            // 
            // textBox4_1_3
            // 
            this.textBox4_1_3.Location = new System.Drawing.Point(2474, 146);
            this.textBox4_1_3.Name = "textBox4_1_3";
            this.textBox4_1_3.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_3.TabIndex = 9;
            this.textBox4_1_3.TextChanged += new System.EventHandler(this.textBox4_1_3_TextChanged);
            // 
            // textBox4_1_2
            // 
            this.textBox4_1_2.Location = new System.Drawing.Point(2474, 96);
            this.textBox4_1_2.Name = "textBox4_1_2";
            this.textBox4_1_2.Size = new System.Drawing.Size(186, 31);
            this.textBox4_1_2.TabIndex = 8;
            this.textBox4_1_2.TextChanged += new System.EventHandler(this.textBox4_1_2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 19);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            this.label1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.label1_MouseClick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1275, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 19);
            this.label2.TabIndex = 10;
            this.label2.Text = "Date";
            this.label2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.label2_MouseClick);
            // 
            // panel8
            // 
            this.panel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel8.BackColor = System.Drawing.Color.LightGray;
            this.panel8.Controls.Add(this.button12);
            this.panel8.Controls.Add(this.button8);
            this.panel8.Controls.Add(this.dataGridView2);
            this.panel8.Controls.Add(this.label9);
            this.panel8.Location = new System.Drawing.Point(326, 105);
            this.panel8.MinimumSize = new System.Drawing.Size(708, 650);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(708, 650);
            this.panel8.TabIndex = 12;
            this.panel8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 25);
            this.label9.TabIndex = 13;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.tabControl1.Location = new System.Drawing.Point(17, 115);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(291, 732);
            this.tabControl1.TabIndex = 17;
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.tabPage1.Controls.Add(this.panel106);
            this.tabPage1.Controls.Add(this.panel107);
            this.tabPage1.Controls.Add(this.label53);
            this.tabPage1.Controls.Add(this.label54);
            this.tabPage1.Controls.Add(this.label56);
            this.tabPage1.Controls.Add(this.label55);
            this.tabPage1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(283, 695);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "진료대기";
            this.tabPage1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage1_MouseClick);
            // 
            // panel106
            // 
            this.panel106.AutoScroll = true;
            this.panel106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.panel106.Location = new System.Drawing.Point(0, 110);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(283, 584);
            this.panel106.TabIndex = 17;
            // 
            // panel107
            // 
            this.panel107.AutoScroll = true;
            this.panel107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.panel107.Location = new System.Drawing.Point(0, 110);
            this.panel107.Name = "panel107";
            this.panel107.Size = new System.Drawing.Size(283, 584);
            this.panel107.TabIndex = 16;
            this.panel107.Visible = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label53.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(103, 66);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(84, 24);
            this.label53.TabIndex = 15;
            this.label53.Text = "진료2실";
            this.label53.Click += new System.EventHandler(this.label53_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label54.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(6, 66);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(79, 24);
            this.label54.TabIndex = 14;
            this.label54.Text = "진료1실";
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(3, 30);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(207, 24);
            this.label56.TabIndex = 13;
            this.label56.Text = "진료 2실 대기인원 : 0";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(3, 4);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(208, 24);
            this.label55.TabIndex = 12;
            this.label55.Text = "진료 1실 대기인원 : 0 ";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(283, 695);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "진료완료";
            this.tabPage2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabPage2_MouseClick);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 10F);
            this.button1.Location = new System.Drawing.Point(12, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 40);
            this.button1.TabIndex = 1;
            this.button1.Text = "환자";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button5.Location = new System.Drawing.Point(1036, 76);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 35);
            this.button5.TabIndex = 11;
            this.button5.TabStop = false;
            this.button5.Text = "검색";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.MouseLeave += new System.EventHandler(this.button5_MouseLeave);
            this.button5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button5_MouseMove);
            // 
            // main_textBox
            // 
            this.main_textBox.Location = new System.Drawing.Point(2334, 16);
            this.main_textBox.Name = "main_textBox";
            this.main_textBox.Size = new System.Drawing.Size(700, 31);
            this.main_textBox.TabIndex = 8;
            this.main_textBox.TabStop = false;
            this.main_textBox.Click += new System.EventHandler(this.main_textBox_Click);
            this.main_textBox.TextChanged += new System.EventHandler(this.main_textBox_TextChanged);
            this.main_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.main_textBox_KeyDown);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(12, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1554, 53);
            this.panel5.TabIndex = 16;
            this.panel5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel5_MouseClick);
            // 
            // panel1_2
            // 
            this.panel1_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel1_2.Location = new System.Drawing.Point(1035, 148);
            this.panel1_2.Name = "panel1_2";
            this.panel1_2.Size = new System.Drawing.Size(1, 697);
            this.panel1_2.TabIndex = 27;
            // 
            // button1_1
            // 
            this.button1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1_1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1_1.FlatAppearance.BorderSize = 0;
            this.button1_1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1_1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14F);
            this.button1_1.Location = new System.Drawing.Point(1446, 76);
            this.button1_1.Name = "button1_1";
            this.button1_1.Size = new System.Drawing.Size(118, 31);
            this.button1_1.TabIndex = 18;
            this.button1_1.Text = "LOG OUT";
            this.button1_1.UseVisualStyleBackColor = true;
            this.button1_1.Click += new System.EventHandler(this.button1_1_Click);
            this.button1_1.MouseLeave += new System.EventHandler(this.button1_1_MouseLeave);
            this.button1_1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button1_1_MouseMove);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(327, 105);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(705, 1);
            this.panel11.TabIndex = 28;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label34.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(332, 74);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(697, 25);
            this.label34.TabIndex = 29;
            this.label34.Text = "검색하실 환자를 입력해주세요.";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.panel123);
            this.panel57.Controls.Add(this.label45);
            this.panel57.Controls.Add(this.panel122);
            this.panel57.Controls.Add(this.label66);
            this.panel57.Controls.Add(this.panel121);
            this.panel57.Controls.Add(this.label65);
            this.panel57.Controls.Add(this.panel116);
            this.panel57.Controls.Add(this.label60);
            this.panel57.Controls.Add(this.panel114);
            this.panel57.Controls.Add(this.label58);
            this.panel57.Controls.Add(this.panel109);
            this.panel57.Controls.Add(this.panel110);
            this.panel57.Controls.Add(this.panel108);
            this.panel57.Controls.Add(this.button21);
            this.panel57.Controls.Add(this.dateTimePicker1);
            this.panel57.Controls.Add(this.Daycontainer1);
            this.panel57.Controls.Add(this.textBox11);
            this.panel57.Controls.Add(this.textBox2);
            this.panel57.Controls.Add(this.button20);
            this.panel57.Controls.Add(this.button16);
            this.panel57.Controls.Add(this.dataGridView4);
            this.panel57.Controls.Add(this.label49);
            this.panel57.Controls.Add(this.label47);
            this.panel57.Controls.Add(this.label46);
            this.panel57.Controls.Add(this.label44);
            this.panel57.Controls.Add(this.button14);
            this.panel57.Controls.Add(this.checkBox4);
            this.panel57.Controls.Add(this.checkBox3);
            this.panel57.Controls.Add(this.checkBox2);
            this.panel57.Controls.Add(this.checkBox1);
            this.panel57.Controls.Add(this.textBox10);
            this.panel57.Controls.Add(this.textBox9);
            this.panel57.Controls.Add(this.textBox8);
            this.panel57.Controls.Add(this.textBox1);
            this.panel57.Controls.Add(this.panel58);
            this.panel57.Controls.Add(this.dataGridView5);
            this.panel57.Location = new System.Drawing.Point(325, 148);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(1240, 697);
            this.panel57.TabIndex = 172;
            this.panel57.Paint += new System.Windows.Forms.PaintEventHandler(this.panel57_Paint);
            // 
            // panel123
            // 
            this.panel123.BackColor = System.Drawing.Color.Black;
            this.panel123.Location = new System.Drawing.Point(22, 679);
            this.panel123.Name = "panel123";
            this.panel123.Size = new System.Drawing.Size(219, 1);
            this.panel123.TabIndex = 180;
            // 
            // label45
            // 
            this.label45.Cursor = System.Windows.Forms.Cursors.Default;
            this.label45.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(22, 651);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(219, 29);
            this.label45.TabIndex = 179;
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // panel122
            // 
            this.panel122.BackColor = System.Drawing.Color.Black;
            this.panel122.Location = new System.Drawing.Point(446, 146);
            this.panel122.Name = "panel122";
            this.panel122.Size = new System.Drawing.Size(186, 1);
            this.panel122.TabIndex = 184;
            // 
            // label66
            // 
            this.label66.Cursor = System.Windows.Forms.Cursors.Default;
            this.label66.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(446, 118);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(186, 29);
            this.label66.TabIndex = 183;
            this.label66.Click += new System.EventHandler(this.label66_Click);
            // 
            // panel121
            // 
            this.panel121.BackColor = System.Drawing.Color.Black;
            this.panel121.Location = new System.Drawing.Point(451, 79);
            this.panel121.Name = "panel121";
            this.panel121.Size = new System.Drawing.Size(141, 1);
            this.panel121.TabIndex = 182;
            // 
            // label65
            // 
            this.label65.Cursor = System.Windows.Forms.Cursors.Default;
            this.label65.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(451, 51);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(141, 29);
            this.label65.TabIndex = 181;
            this.label65.Click += new System.EventHandler(this.label65_Click);
            // 
            // panel116
            // 
            this.panel116.BackColor = System.Drawing.Color.Black;
            this.panel116.Location = new System.Drawing.Point(119, 146);
            this.panel116.Name = "panel116";
            this.panel116.Size = new System.Drawing.Size(199, 1);
            this.panel116.TabIndex = 180;
            // 
            // label60
            // 
            this.label60.Cursor = System.Windows.Forms.Cursors.Default;
            this.label60.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(119, 118);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(198, 29);
            this.label60.TabIndex = 179;
            this.label60.Click += new System.EventHandler(this.label60_Click);
            // 
            // panel114
            // 
            this.panel114.BackColor = System.Drawing.Color.Black;
            this.panel114.Location = new System.Drawing.Point(119, 79);
            this.panel114.Name = "panel114";
            this.panel114.Size = new System.Drawing.Size(172, 1);
            this.panel114.TabIndex = 178;
            // 
            // label58
            // 
            this.label58.Cursor = System.Windows.Forms.Cursors.Default;
            this.label58.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(119, 51);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(172, 29);
            this.label58.TabIndex = 177;
            // 
            // panel109
            // 
            this.panel109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel109.Location = new System.Drawing.Point(695, 428);
            this.panel109.Name = "panel109";
            this.panel109.Size = new System.Drawing.Size(545, 1);
            this.panel109.TabIndex = 27;
            // 
            // panel110
            // 
            this.panel110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel110.Location = new System.Drawing.Point(691, 1);
            this.panel110.Name = "panel110";
            this.panel110.Size = new System.Drawing.Size(1, 697);
            this.panel110.TabIndex = 27;
            // 
            // panel108
            // 
            this.panel108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(223)))), ((int)(((byte)(242)))));
            this.panel108.Location = new System.Drawing.Point(0, 270);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(692, 1);
            this.panel108.TabIndex = 47;
            // 
            // button21
            // 
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button21.Location = new System.Drawing.Point(562, 556);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(130, 32);
            this.button21.TabIndex = 46;
            this.button21.Text = "수정하기";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            this.button21.MouseLeave += new System.EventHandler(this.button21_MouseLeave);
            this.button21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button21_MouseMove);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(247, 649);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(234, 32);
            this.dateTimePicker1.TabIndex = 45;
            // 
            // Daycontainer1
            // 
            this.Daycontainer1.Controls.Add(this.panel59);
            this.Daycontainer1.Controls.Add(this.panel60);
            this.Daycontainer1.Controls.Add(this.panel61);
            this.Daycontainer1.Controls.Add(this.panel62);
            this.Daycontainer1.Controls.Add(this.panel63);
            this.Daycontainer1.Controls.Add(this.panel64);
            this.Daycontainer1.Controls.Add(this.panel65);
            this.Daycontainer1.Controls.Add(this.panel66);
            this.Daycontainer1.Controls.Add(this.panel67);
            this.Daycontainer1.Controls.Add(this.panel68);
            this.Daycontainer1.Controls.Add(this.panel69);
            this.Daycontainer1.Controls.Add(this.panel70);
            this.Daycontainer1.Controls.Add(this.panel71);
            this.Daycontainer1.Controls.Add(this.panel72);
            this.Daycontainer1.Controls.Add(this.panel73);
            this.Daycontainer1.Controls.Add(this.panel74);
            this.Daycontainer1.Controls.Add(this.panel75);
            this.Daycontainer1.Controls.Add(this.panel76);
            this.Daycontainer1.Controls.Add(this.panel77);
            this.Daycontainer1.Controls.Add(this.panel78);
            this.Daycontainer1.Controls.Add(this.panel79);
            this.Daycontainer1.Controls.Add(this.panel80);
            this.Daycontainer1.Controls.Add(this.panel81);
            this.Daycontainer1.Controls.Add(this.panel82);
            this.Daycontainer1.Controls.Add(this.panel83);
            this.Daycontainer1.Controls.Add(this.panel84);
            this.Daycontainer1.Controls.Add(this.panel85);
            this.Daycontainer1.Controls.Add(this.panel86);
            this.Daycontainer1.Controls.Add(this.panel87);
            this.Daycontainer1.Controls.Add(this.panel88);
            this.Daycontainer1.Controls.Add(this.panel89);
            this.Daycontainer1.Controls.Add(this.panel90);
            this.Daycontainer1.Controls.Add(this.panel91);
            this.Daycontainer1.Controls.Add(this.panel92);
            this.Daycontainer1.Controls.Add(this.panel93);
            this.Daycontainer1.Controls.Add(this.panel94);
            this.Daycontainer1.Controls.Add(this.panel95);
            this.Daycontainer1.Controls.Add(this.panel96);
            this.Daycontainer1.Controls.Add(this.panel97);
            this.Daycontainer1.Controls.Add(this.panel98);
            this.Daycontainer1.Controls.Add(this.panel99);
            this.Daycontainer1.Controls.Add(this.panel100);
            this.Daycontainer1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Daycontainer1.Location = new System.Drawing.Point(692, 95);
            this.Daycontainer1.Name = "Daycontainer1";
            this.Daycontainer1.Size = new System.Drawing.Size(545, 334);
            this.Daycontainer1.TabIndex = 44;
            // 
            // panel59
            // 
            this.panel59.AutoSize = true;
            this.panel59.BackColor = System.Drawing.SystemColors.Info;
            this.panel59.Location = new System.Drawing.Point(3, 3);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(0, 0);
            this.panel59.TabIndex = 0;
            // 
            // panel60
            // 
            this.panel60.AutoSize = true;
            this.panel60.BackColor = System.Drawing.SystemColors.Info;
            this.panel60.Location = new System.Drawing.Point(9, 3);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(0, 0);
            this.panel60.TabIndex = 1;
            // 
            // panel61
            // 
            this.panel61.AutoSize = true;
            this.panel61.BackColor = System.Drawing.SystemColors.Info;
            this.panel61.Location = new System.Drawing.Point(15, 3);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(0, 0);
            this.panel61.TabIndex = 2;
            // 
            // panel62
            // 
            this.panel62.AutoSize = true;
            this.panel62.BackColor = System.Drawing.SystemColors.Info;
            this.panel62.Location = new System.Drawing.Point(21, 3);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(0, 0);
            this.panel62.TabIndex = 3;
            // 
            // panel63
            // 
            this.panel63.AutoSize = true;
            this.panel63.BackColor = System.Drawing.SystemColors.Info;
            this.panel63.Location = new System.Drawing.Point(27, 3);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(0, 0);
            this.panel63.TabIndex = 4;
            // 
            // panel64
            // 
            this.panel64.AutoSize = true;
            this.panel64.BackColor = System.Drawing.SystemColors.Info;
            this.panel64.Location = new System.Drawing.Point(33, 3);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(0, 0);
            this.panel64.TabIndex = 6;
            // 
            // panel65
            // 
            this.panel65.AutoSize = true;
            this.panel65.BackColor = System.Drawing.SystemColors.Info;
            this.panel65.Location = new System.Drawing.Point(39, 3);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(0, 0);
            this.panel65.TabIndex = 5;
            // 
            // panel66
            // 
            this.panel66.AutoSize = true;
            this.panel66.BackColor = System.Drawing.SystemColors.Info;
            this.panel66.Location = new System.Drawing.Point(45, 3);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(0, 0);
            this.panel66.TabIndex = 14;
            // 
            // panel67
            // 
            this.panel67.AutoSize = true;
            this.panel67.BackColor = System.Drawing.SystemColors.Info;
            this.panel67.Location = new System.Drawing.Point(51, 3);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(0, 0);
            this.panel67.TabIndex = 22;
            // 
            // panel68
            // 
            this.panel68.AutoSize = true;
            this.panel68.BackColor = System.Drawing.SystemColors.Info;
            this.panel68.Location = new System.Drawing.Point(57, 3);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(0, 0);
            this.panel68.TabIndex = 23;
            // 
            // panel69
            // 
            this.panel69.AutoSize = true;
            this.panel69.BackColor = System.Drawing.SystemColors.Info;
            this.panel69.Location = new System.Drawing.Point(63, 3);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(0, 0);
            this.panel69.TabIndex = 24;
            // 
            // panel70
            // 
            this.panel70.AutoSize = true;
            this.panel70.BackColor = System.Drawing.SystemColors.Info;
            this.panel70.Location = new System.Drawing.Point(69, 3);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(0, 0);
            this.panel70.TabIndex = 25;
            // 
            // panel71
            // 
            this.panel71.AutoSize = true;
            this.panel71.BackColor = System.Drawing.SystemColors.Info;
            this.panel71.Location = new System.Drawing.Point(75, 3);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(0, 0);
            this.panel71.TabIndex = 27;
            // 
            // panel72
            // 
            this.panel72.AutoSize = true;
            this.panel72.BackColor = System.Drawing.SystemColors.Info;
            this.panel72.Location = new System.Drawing.Point(81, 3);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(0, 0);
            this.panel72.TabIndex = 26;
            // 
            // panel73
            // 
            this.panel73.AutoSize = true;
            this.panel73.BackColor = System.Drawing.SystemColors.Info;
            this.panel73.Location = new System.Drawing.Point(87, 3);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(0, 0);
            this.panel73.TabIndex = 21;
            // 
            // panel74
            // 
            this.panel74.AutoSize = true;
            this.panel74.BackColor = System.Drawing.SystemColors.Info;
            this.panel74.Location = new System.Drawing.Point(93, 3);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(0, 0);
            this.panel74.TabIndex = 19;
            // 
            // panel75
            // 
            this.panel75.AutoSize = true;
            this.panel75.BackColor = System.Drawing.SystemColors.Info;
            this.panel75.Location = new System.Drawing.Point(99, 3);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(0, 0);
            this.panel75.TabIndex = 20;
            // 
            // panel76
            // 
            this.panel76.AutoSize = true;
            this.panel76.BackColor = System.Drawing.SystemColors.Info;
            this.panel76.Location = new System.Drawing.Point(105, 3);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(0, 0);
            this.panel76.TabIndex = 18;
            // 
            // panel77
            // 
            this.panel77.AutoSize = true;
            this.panel77.BackColor = System.Drawing.SystemColors.Info;
            this.panel77.Location = new System.Drawing.Point(111, 3);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(0, 0);
            this.panel77.TabIndex = 17;
            // 
            // panel78
            // 
            this.panel78.AutoSize = true;
            this.panel78.BackColor = System.Drawing.SystemColors.Info;
            this.panel78.Location = new System.Drawing.Point(117, 3);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(0, 0);
            this.panel78.TabIndex = 16;
            // 
            // panel79
            // 
            this.panel79.AutoSize = true;
            this.panel79.BackColor = System.Drawing.SystemColors.Info;
            this.panel79.Location = new System.Drawing.Point(123, 3);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(0, 0);
            this.panel79.TabIndex = 15;
            // 
            // panel80
            // 
            this.panel80.AutoSize = true;
            this.panel80.BackColor = System.Drawing.SystemColors.Info;
            this.panel80.Location = new System.Drawing.Point(129, 3);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(0, 0);
            this.panel80.TabIndex = 28;
            // 
            // panel81
            // 
            this.panel81.AutoSize = true;
            this.panel81.BackColor = System.Drawing.SystemColors.Info;
            this.panel81.Location = new System.Drawing.Point(135, 3);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(0, 0);
            this.panel81.TabIndex = 29;
            // 
            // panel82
            // 
            this.panel82.AutoSize = true;
            this.panel82.BackColor = System.Drawing.SystemColors.Info;
            this.panel82.Location = new System.Drawing.Point(141, 3);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(0, 0);
            this.panel82.TabIndex = 30;
            // 
            // panel83
            // 
            this.panel83.AutoSize = true;
            this.panel83.BackColor = System.Drawing.SystemColors.Info;
            this.panel83.Location = new System.Drawing.Point(147, 3);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(0, 0);
            this.panel83.TabIndex = 31;
            // 
            // panel84
            // 
            this.panel84.AutoSize = true;
            this.panel84.BackColor = System.Drawing.SystemColors.Info;
            this.panel84.Location = new System.Drawing.Point(153, 3);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(0, 0);
            this.panel84.TabIndex = 32;
            // 
            // panel85
            // 
            this.panel85.AutoSize = true;
            this.panel85.BackColor = System.Drawing.SystemColors.Info;
            this.panel85.Location = new System.Drawing.Point(159, 3);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(0, 0);
            this.panel85.TabIndex = 34;
            // 
            // panel86
            // 
            this.panel86.AutoSize = true;
            this.panel86.BackColor = System.Drawing.SystemColors.Info;
            this.panel86.Location = new System.Drawing.Point(165, 3);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(0, 0);
            this.panel86.TabIndex = 33;
            // 
            // panel87
            // 
            this.panel87.AutoSize = true;
            this.panel87.BackColor = System.Drawing.SystemColors.Info;
            this.panel87.Location = new System.Drawing.Point(171, 3);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(0, 0);
            this.panel87.TabIndex = 35;
            // 
            // panel88
            // 
            this.panel88.AutoSize = true;
            this.panel88.BackColor = System.Drawing.SystemColors.Info;
            this.panel88.Location = new System.Drawing.Point(177, 3);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(0, 0);
            this.panel88.TabIndex = 40;
            // 
            // panel89
            // 
            this.panel89.AutoSize = true;
            this.panel89.BackColor = System.Drawing.SystemColors.Info;
            this.panel89.Location = new System.Drawing.Point(183, 3);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(0, 0);
            this.panel89.TabIndex = 41;
            // 
            // panel90
            // 
            this.panel90.AutoSize = true;
            this.panel90.BackColor = System.Drawing.SystemColors.Info;
            this.panel90.Location = new System.Drawing.Point(189, 3);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(0, 0);
            this.panel90.TabIndex = 39;
            // 
            // panel91
            // 
            this.panel91.AutoSize = true;
            this.panel91.BackColor = System.Drawing.SystemColors.Info;
            this.panel91.Location = new System.Drawing.Point(195, 3);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(0, 0);
            this.panel91.TabIndex = 38;
            // 
            // panel92
            // 
            this.panel92.AutoSize = true;
            this.panel92.BackColor = System.Drawing.SystemColors.Info;
            this.panel92.Location = new System.Drawing.Point(201, 3);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(0, 0);
            this.panel92.TabIndex = 37;
            // 
            // panel93
            // 
            this.panel93.AutoSize = true;
            this.panel93.BackColor = System.Drawing.SystemColors.Info;
            this.panel93.Location = new System.Drawing.Point(207, 3);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(0, 0);
            this.panel93.TabIndex = 36;
            // 
            // panel94
            // 
            this.panel94.AutoSize = true;
            this.panel94.BackColor = System.Drawing.SystemColors.Info;
            this.panel94.Location = new System.Drawing.Point(213, 3);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(0, 0);
            this.panel94.TabIndex = 7;
            // 
            // panel95
            // 
            this.panel95.AutoSize = true;
            this.panel95.BackColor = System.Drawing.SystemColors.Info;
            this.panel95.Location = new System.Drawing.Point(219, 3);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(0, 0);
            this.panel95.TabIndex = 12;
            // 
            // panel96
            // 
            this.panel96.AutoSize = true;
            this.panel96.BackColor = System.Drawing.SystemColors.Info;
            this.panel96.Location = new System.Drawing.Point(225, 3);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(0, 0);
            this.panel96.TabIndex = 13;
            // 
            // panel97
            // 
            this.panel97.AutoSize = true;
            this.panel97.BackColor = System.Drawing.SystemColors.Info;
            this.panel97.Location = new System.Drawing.Point(231, 3);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(0, 0);
            this.panel97.TabIndex = 11;
            // 
            // panel98
            // 
            this.panel98.AutoSize = true;
            this.panel98.BackColor = System.Drawing.SystemColors.Info;
            this.panel98.Location = new System.Drawing.Point(237, 3);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(0, 0);
            this.panel98.TabIndex = 10;
            // 
            // panel99
            // 
            this.panel99.AutoSize = true;
            this.panel99.BackColor = System.Drawing.SystemColors.Info;
            this.panel99.Location = new System.Drawing.Point(243, 3);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(0, 0);
            this.panel99.TabIndex = 9;
            // 
            // panel100
            // 
            this.panel100.AutoSize = true;
            this.panel100.BackColor = System.Drawing.SystemColors.Info;
            this.panel100.Location = new System.Drawing.Point(249, 3);
            this.panel100.Name = "panel100";
            this.panel100.Size = new System.Drawing.Size(0, 0);
            this.panel100.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(2247, 651);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(234, 31);
            this.textBox11.TabIndex = 30;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(2017, 650);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(222, 31);
            this.textBox2.TabIndex = 29;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button20
            // 
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button20.Location = new System.Drawing.Point(562, 650);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(130, 32);
            this.button20.TabIndex = 28;
            this.button20.Text = "예약하기";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            this.button20.MouseLeave += new System.EventHandler(this.button20_MouseLeave);
            this.button20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button20_MouseMove);
            // 
            // button16
            // 
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 16F);
            this.button16.Location = new System.Drawing.Point(562, 603);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(130, 32);
            this.button16.TabIndex = 1;
            this.button16.Text = "삭제하기";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            this.button16.MouseLeave += new System.EventHandler(this.button16_MouseLeave);
            this.button16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button16_MouseMove);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AllowUserToResizeColumns = false;
            this.dataGridView4.AllowUserToResizeRows = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column47,
            this.Column48,
            this.Column49,
            this.Column51,
            this.Column50});
            this.dataGridView4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView4.Location = new System.Drawing.Point(3, 273);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4.Size = new System.Drawing.Size(689, 422);
            this.dataGridView4.TabIndex = 0;
            // 
            // Column47
            // 
            this.Column47.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column47.DefaultCellStyle = dataGridViewCellStyle63;
            this.Column47.HeaderText = "시간";
            this.Column47.Name = "Column47";
            this.Column47.ReadOnly = true;
            this.Column47.Width = 69;
            // 
            // Column48
            // 
            this.Column48.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle64.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column48.DefaultCellStyle = dataGridViewCellStyle64;
            this.Column48.HeaderText = "이름";
            this.Column48.Name = "Column48";
            this.Column48.ReadOnly = true;
            this.Column48.Width = 69;
            // 
            // Column49
            // 
            this.Column49.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle65.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column49.DefaultCellStyle = dataGridViewCellStyle65;
            this.Column49.HeaderText = "생년월일";
            this.Column49.Name = "Column49";
            this.Column49.ReadOnly = true;
            // 
            // Column51
            // 
            this.Column51.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle66.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column51.DefaultCellStyle = dataGridViewCellStyle66;
            this.Column51.HeaderText = "전화번호";
            this.Column51.Name = "Column51";
            this.Column51.ReadOnly = true;
            // 
            // Column50
            // 
            this.Column50.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle67.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column50.DefaultCellStyle = dataGridViewCellStyle67;
            this.Column50.HeaderText = "주소";
            this.Column50.Name = "Column50";
            this.Column50.ReadOnly = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(337, 51);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(90, 24);
            this.label49.TabIndex = 25;
            this.label49.Text = "생년월일";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(41, 118);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(56, 24);
            this.label47.TabIndex = 23;
            this.label47.Text = "주 소";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(337, 118);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(90, 24);
            this.label46.TabIndex = 22;
            this.label46.Text = "전화번호";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(41, 51);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 24);
            this.label44.TabIndex = 20;
            this.label44.Text = "이 름";
            // 
            // button14
            // 
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(529, 221);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(137, 37);
            this.button14.TabIndex = 19;
            this.button14.Text = "문서 출력";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.MouseLeave += new System.EventHandler(this.button14_MouseLeave);
            this.button14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button14_MouseMove);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox4.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(372, 205);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(109, 28);
            this.checkBox4.TabIndex = 18;
            this.checkBox4.Text = "문자거부";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox3.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(225, 205);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(104, 28);
            this.checkBox3.TabIndex = 17;
            this.checkBox3.Text = "알림톡X";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(33, 205);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(161, 28);
            this.checkBox2.TabIndex = 16;
            this.checkBox2.Text = "정보 제공 동의";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.Font = new System.Drawing.Font("G마켓 산스 TTF Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(598, 50);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(69, 28);
            this.checkBox1.TabIndex = 15;
            this.checkBox1.Text = "음력";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(2150, 177);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(138, 31);
            this.textBox10.TabIndex = 12;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(2488, 122);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(195, 31);
            this.textBox9.TabIndex = 11;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(2476, 66);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(172, 31);
            this.textBox8.TabIndex = 10;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(2152, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(195, 31);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.Color.White;
            this.panel58.Controls.Add(this.label36);
            this.panel58.Controls.Add(this.button9);
            this.panel58.Controls.Add(this.label37);
            this.panel58.Controls.Add(this.label38);
            this.panel58.Controls.Add(this.label39);
            this.panel58.Controls.Add(this.label40);
            this.panel58.Controls.Add(this.label41);
            this.panel58.Controls.Add(this.label42);
            this.panel58.Controls.Add(this.label43);
            this.panel58.Controls.Add(this.button10);
            this.panel58.Location = new System.Drawing.Point(692, 1);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(547, 428);
            this.panel58.TabIndex = 6;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(200, 12);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(159, 29);
            this.label36.TabIndex = 42;
            this.label36.Text = "Month YEAR";
            // 
            // button9
            // 
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button9.Location = new System.Drawing.Point(50, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(87, 39);
            this.button9.TabIndex = 41;
            this.button9.Text = "지난달";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            this.button9.MouseLeave += new System.EventHandler(this.button9_MouseLeave);
            this.button9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button9_MouseMove);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(43, 57);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(32, 29);
            this.label37.TabIndex = 21;
            this.label37.Text = "일";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(492, 57);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(32, 29);
            this.label38.TabIndex = 20;
            this.label38.Text = "토";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(418, 57);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 29);
            this.label39.TabIndex = 19;
            this.label39.Text = "금";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(343, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(32, 29);
            this.label40.TabIndex = 18;
            this.label40.Text = "목";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(265, 57);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(32, 29);
            this.label41.TabIndex = 17;
            this.label41.Text = "수";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(190, 57);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 29);
            this.label42.TabIndex = 16;
            this.label42.Text = "화";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(115, 57);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(32, 29);
            this.label43.TabIndex = 15;
            this.label43.Text = "월";
            // 
            // button10
            // 
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.button10.Location = new System.Drawing.Point(419, 12);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(87, 39);
            this.button10.TabIndex = 40;
            this.button10.Text = "다음달";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            this.button10.MouseLeave += new System.EventHandler(this.button10_MouseLeave);
            this.button10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button10_MouseMove);
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column46,
            this.Column55,
            this.Column56});
            this.dataGridView5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView5.Location = new System.Drawing.Point(692, 429);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersVisible = false;
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView5.Size = new System.Drawing.Size(547, 267);
            this.dataGridView5.TabIndex = 1;
            this.dataGridView5.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellContentDoubleClick);
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "이름";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 69;
            // 
            // Column46
            // 
            this.Column46.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column46.HeaderText = "생년월일";
            this.Column46.Name = "Column46";
            this.Column46.ReadOnly = true;
            // 
            // Column55
            // 
            this.Column55.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column55.HeaderText = "이전진료일자";
            this.Column55.Name = "Column55";
            this.Column55.ReadOnly = true;
            // 
            // Column56
            // 
            this.Column56.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column56.HeaderText = "증상";
            this.Column56.Name = "Column56";
            this.Column56.ReadOnly = true;
            // 
            // Form_main
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1584, 861);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel57);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1_2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.main_textBox);
            this.Controls.Add(this.button1_1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "P";
            this.Load += new System.EventHandler(this.Form_main_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form_main_MouseClick);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3_3_1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.Daycontainer.ResumeLayout(false);
            this.Daycontainer.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_1)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel4_2.ResumeLayout(false);
            this.panel4_2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_5)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4_6)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.Daycontainer1.ResumeLayout(false);
            this.Daycontainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.panel58.ResumeLayout(false);
            this.panel58.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button3_1_3;
        public System.Windows.Forms.Button button3_2_1;
        public System.Windows.Forms.TextBox textBox3_2_1;
        public System.Windows.Forms.TextBox textBox3_1_1;
        public System.Windows.Forms.Button button3_3_3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button8;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3_3_1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button button7;
        public System.Windows.Forms.DataGridView dataGridView3_2_1;
        private System.Windows.Forms.Button button5;
        public System.Windows.Forms.TextBox main_textBox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button19;
        public System.Windows.Forms.DataGridView dataGridView3_3_1;
        public System.Windows.Forms.TextBox textBox3_3_1;
        public System.Windows.Forms.Button button3_3_2;
        public System.Windows.Forms.Button button3_3_1;
        public System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.FlowLayoutPanel Daycontainer;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel23;
        public System.Windows.Forms.TextBox textBox3_1_2;
        private System.Windows.Forms.Label label3_1_2;
        private System.Windows.Forms.Label label3_1_4;
        public System.Windows.Forms.DataGridView dataGridView4_1;
        private System.Windows.Forms.Button button11;
        public System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel1_1;
        private System.Windows.Forms.Panel panel1_2;
        private System.Windows.Forms.Button button1_1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1_6;
        private System.Windows.Forms.Panel panel1_5;
        private System.Windows.Forms.Panel panel1_4;
        private System.Windows.Forms.Panel panel1_3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label34;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.FlowLayoutPanel Daycontainer1;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Panel panel100;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Panel panel101;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.Panel panel104;
        public System.Windows.Forms.Label label3_2_1;
        private System.Windows.Forms.Button button4_1_1;
        public System.Windows.Forms.TextBox textBox4_1_6;
        private System.Windows.Forms.Label label4_6;
        private System.Windows.Forms.Label label4_1;
        public System.Windows.Forms.TextBox textBox4_1_5;
        private System.Windows.Forms.Label label4_2;
        private System.Windows.Forms.Label label4_5;
        private System.Windows.Forms.Label label4_3;
        public System.Windows.Forms.Panel panel4_1_1;
        private System.Windows.Forms.Label label4_4;
        public System.Windows.Forms.TextBox textBox4_1_4;
        public System.Windows.Forms.TextBox textBox4_1_1;
        public System.Windows.Forms.TextBox textBox4_1_3;
        public System.Windows.Forms.TextBox textBox4_1_2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.DataGridView dataGridView4_2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel4_2;
        private System.Windows.Forms.Button button4_2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button4_1;
        private System.Windows.Forms.Label label3_1_3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label3_1_5;
        public System.Windows.Forms.Panel panel10;
        public System.Windows.Forms.Label label3_2_2;
        public System.Windows.Forms.Panel panel105;
        public System.Windows.Forms.Label label3_3_2;
        public System.Windows.Forms.Panel panel106;
        public System.Windows.Forms.Panel panel107;
        public System.Windows.Forms.Label label53;
        public System.Windows.Forms.Label label54;
        public System.Windows.Forms.Label label56;
        public System.Windows.Forms.Label label55;
        private System.Windows.Forms.Panel panel109;
        private System.Windows.Forms.Panel panel110;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Panel panel111;
        private System.Windows.Forms.Panel panel112;
        private System.Windows.Forms.Panel panel113;
        private System.Windows.Forms.Panel panel115;
        private System.Windows.Forms.Panel panel117;
        private System.Windows.Forms.Panel panel119;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Panel panel118;
        private System.Windows.Forms.Panel panel114;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Panel panel116;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel panel121;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel122;
        private System.Windows.Forms.Label label66;
        public System.Windows.Forms.DataGridView dataGridView4_5;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button button4_4;
        private System.Windows.Forms.Panel panel123;
        private System.Windows.Forms.Label label45;
        public System.Windows.Forms.Button button3_2_2;
        private System.Windows.Forms.Label label3_1_1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.DataGridView dataGridView4_7;
        private System.Windows.Forms.Button button4_5;
        private System.Windows.Forms.Button button4_3;
        private System.Windows.Forms.Label label29;
        public System.Windows.Forms.DataGridView dataGridView4_6;
        public System.Windows.Forms.DataGridView dataGridView7;
        public System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel132;
        public System.Windows.Forms.Label label70;
        private System.Windows.Forms.Panel panel131;
        public System.Windows.Forms.Label label69;
        private System.Windows.Forms.Panel panel130;
        public System.Windows.Forms.Label label68;
        private System.Windows.Forms.Panel panel129;
        public System.Windows.Forms.Label label64;
        private System.Windows.Forms.Panel panel128;
        public System.Windows.Forms.Label label62;
        private System.Windows.Forms.Panel panel127;
        public System.Windows.Forms.Label label61;
        private System.Windows.Forms.Panel panel126;
        public System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel panel125;
        public System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel panel124;
        public System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel120;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column41;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column43;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column44;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column45;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column37;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column39;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column52;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column40;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column53;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column54;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column34;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column47;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column48;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column49;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column51;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column50;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column18;
        public System.Windows.Forms.Label label4_1_2;
        public System.Windows.Forms.Label label4_1_3;
        public System.Windows.Forms.Label label4_1_4;
        public System.Windows.Forms.Label label4_1_5;
        public System.Windows.Forms.Label label4_1_6;
        public System.Windows.Forms.Label label4_1_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column46;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column55;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column56;
        private System.Windows.Forms.Button button4_6;
    }
}